import requests
from bs4 import BeautifulSoup
import jsbeautifier
import re
import json
from resources.Common import logger
from resources.Common import tools



def getLinksLatinoWebTV2():
    res=[]
    resLink=[]
    resImg=[]
    dict={}
    url="https://www.latino-web-tv.com"
    req=requests.get(url)
    soup=BeautifulSoup(req.content, 'html.parser')
    job_elems =  soup.find_all('div', class_='elementor-image')
    for links in job_elems:
        resultLinks=links.find_all('a')
        resultImg = links.find_all('img')
        resultUrl = resultLinks[0].get('href')
        image = resultImg[0].get('src')
        regex = r"www\.latino-web-tv\.com\/(.*?)\/"
        nombre=tools.findall(regex,resultUrl,re.MULTILINE)[0]
        nombre=nombre.replace('-',' ').replace(' en vivo','')
        nombre=nombre.upper()

        dict={'url':resultUrl,'imagen':image,'nombre':nombre}
        res.append(dict)
    return res

def getPassphrase_CadenaEncriptadaB64(url):
        s = requests.Session()
        req = s.get(url)
        # cookies=req.cookies
        # regex = r"(eval.*?\}\)\))"
        regex = r"src=\"(.*?embed\.latino.*?)(?:\s|\")"
        new_url = tools.findall(regex, req.text, re.MULTILINE)[0]
        req = s.get(new_url)
        regex = r"(eval.*?\}\)\))"
        packed = tools.findall(regex, req.text, re.MULTILINE)[0]
        encrypted = packed

        # encrypted = r'''eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('6 u(){d b=/1L/i.14(s.15)||(6(c){8 c.16()==="[17 18]"})(!s.m||(19 m!=="1a"&&m.1b));g(b){8 f}g(s.13&&D()>=x){8 f}d n=r.q.t(/1c\\/([0-9]{2,})/i);g(n&&B(n[1])>=x){8 f}d a=(r.q.t(/1e|1f\\//)?f:l);g(a){8 f}8 l}6 D(){d b=r.q.t(/1g(e|1h)\\/([0-9]+)\\./);8 b?B(b[2],10):l};d k;d o;$.1i({1j:"/j.1k",1l:"1m",j:{1d:"0"},12:6(j,V,Z){7=O N.M({P:U.W(j["S"]),Y:"#7",X:"T",R:[Q],1n:u(),1p:!1,1K:{22:"#F",20:"#F"},1Y:"G%",1N:"G%",1S:{"1Q":{"w":"1o - y-C-A.z",},"1W":{"w":"1M 1O - y-C-A.z",},},1P:{1R:6(e){v()}},1T:{1U:\'1V\',1X:{5:\'1Z\',4:\'21\',3:\'1A\',2:\'1r\',1:\'1s\',0:\'1t\',}}});H(6(){7.p();1u.1v("p!")},1w)},});6 v(){$(".J-K").L("E","1x");k=10;o=1y(6(){1q.1z("1B").1C=10- --k;g(k<=0)1D(o)},1E);H(6(){I()},1F)}6 I(){$(".J-K").L("E","1G");d h=7.1H(7);h=O N.M(h.1I);7.1J();7=h;7.p();7.11()}',62,127,'||||||function|player|return|||||var||true|if|newplayer||data|timeleft|false|safari|ff|downloadTimer|play|userAgent|navigator|window|match|startMuted|errorPlaying|live|66|Latino|com|TV|parseInt|Web|getChromeVersion|display|00FD2A|100|setTimeout|relOadPlayer|stream|offline|css|Player|Clappr|new|source|LevelSelector|plugins|streamdata|auto|MARIOCSCRYPT|textStatus|load_data|preload|parentId|jqXHR||unmute|success|chrome|test|HTMLElement|toString|object|SafariRemoteNotification|typeof|undefined|pushNotification|firefox|id|Opera|OPR|Chrom|ium|ajax|url|json|type|POST|mute|LIVE|autoPlay|document|360p|240p|144p|console|log|500|table|setInterval|getElementById|480p|progressBar|value|clearInterval|1000|10000|none|configure|options|destroy|mediacontrol|constructor|EN|height|VIVO|events|en|onError|strings|levelSelectorConfig|title|Quality|es|labels|width|1080p|buttons|720p|seekbar'.split('|'),0,{}))'''
        unpacked = jsbeautifier.beautify(encrypted)
        print(unpacked)
        # de aqui nos vale el id y la direccion del json
        regexid = r"id:\s*\"(\d*)\""
        id = tools.findall(regexid, unpacked, re.MULTILINE)[0]
        regexJson = r"url:\s*\"(.*?)\""
        argumento = tools.findall(regexJson, unpacked, re.MULTILINE)[0]
        urlJson = "https://embed.latino-web-tv.com" + argumento
        # de este me vale el pass
        js = "https://embed.latino-web-tv.com/config-player.js"
        req = s.get(js)
        unpacked = jsbeautifier.beautify(req.text)
        regexpassword = r"openSSLKey.*?\"(.*?)\""


        passwordAes = tools.findall(regexpassword, unpacked, re.MULTILINE)[0]

        # ahora obtenemos los datos encryptados
        postdata = {'id': id}
        req = s.post(urlJson, data=postdata, headers={'referer': 'https://embed.latino-web-tv.com/tnt',
                                                      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 OPR/72.0.3815.400',
                                                      'Origin': 'https://embed.latino-web-tv.com'})
        json_data = json.loads(req.text)
        #import web_pdb;web_pdb.set_trace()
        cadenaEncryptada = json_data['streamdata']

        return passwordAes, cadenaEncryptada
