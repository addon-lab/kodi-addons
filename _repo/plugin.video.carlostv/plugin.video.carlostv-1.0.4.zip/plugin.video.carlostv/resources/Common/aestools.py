import hashlib, binascii
#from passlib.utils.pbkdf2 import pbkdf1
#from lib.passlib.utils.pbkdf2 import pbkdf1

def hasher(algo, data):
    hashes = {'md5': hashlib.md5, 'sha256': hashlib.sha256,
    'sha512': hashlib.sha512}
    h = hashes[algo]()
    h.update(data)

    return h.digest()

def EVP_BytesToKey(password, salt, key_len, iv_len):
    """
    Derive the key and the IV from the given password and salt.
    """
    from hashlib import md5
    dtot =  md5(password + salt).digest()
    d = [ dtot ]
    while len(dtot)<(iv_len+key_len):
        d.append( md5(d[-1] + password + salt).digest() )
        dtot += d[-1]
    return dtot[:key_len], dtot[key_len:key_len+iv_len]

# pwd and salt must be bytes objects
# def openssl_kdf(algo, pwd, salt, key_size, iv_size):
#     if algo == 'md5':
#         temp = pbkdf1(pwd, salt, 1, 16, 'md5')
#     else:
#         temp = b''
#
#     fd = temp
#     while len(fd) < key_size + iv_size:
#         temp = hasher(algo, temp + pwd + salt)
#         fd += temp
#
#     key = fd[0:key_size]
#     iv = fd[key_size:key_size+iv_size]
#
#     print('salt=' + binascii.hexlify(salt).decode('ascii').upper())
#     print('key=' + binascii.hexlify(key).decode('ascii').upper())
#     print('iv=' + binascii.hexlify(iv).decode('ascii').upper())
#
#     return key, iv