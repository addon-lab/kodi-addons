# -*- coding: utf-8 -*-

import os
import sys
import re
import xbmcplugin
import urlparse
#import json
#import requests
#from bs4 import BeautifulSoup
#import jsbeautifier
import base64


from resources.lib.pyaes.aes import AES, AESModeOfOperationCTR, AESModeOfOperationCBC, AESModeOfOperationCFB, AESModeOfOperationECB, AESModeOfOperationOFB, AESModesOfOperation, Counter
from resources.lib.pyaes.blockfeeder import decrypt_stream, Decrypter, encrypt_stream, Encrypter
from resources.lib.pyaes.blockfeeder import PADDING_NONE, PADDING_DEFAULT
from resources.lib.pyaes.openssl_aes import AESCipher


from resources.Common.aestools import EVP_BytesToKey
from resources.Common.latino import getLinksLatinoWebTV2,getPassphrase_CadenaEncriptadaB64

from resources.Common import logger
from resources.Common import tools

args = urlparse.parse_qs(sys.argv[2][1:])
#recupera el argumento action
action = args.get('action', None)
domain = "https://www.latino-web-tv.com"
addon_handle = int(sys.argv[1])



if action is None:

    #Aquí sólo entra la primera vez para que el usuario pueda escoger categorías (fotos o videos)
    matches=getLinksLatinoWebTV2()

    for match in matches:
        urlvalue=match['url']
        imagen=match['imagen']
        nombreCanal=match['nombre']
        url = tools.build_url({'action': 'canal', 'url_': urlvalue,'imagen':imagen,'nombre':nombreCanal})

        pattern = 'alt="(.*)"'
        label = nombreCanal
        thumbnail = imagen
        tools.addItemMenu(label = label,thumbnail= thumbnail, url= url,IsPlayable = 'false', isFolder= True)

    xbmcplugin.endOfDirectory(addon_handle) 

else:
   
    if action[0] == 'canal':
        #import web_pdb;web_pdb.set_trace()
        url_ = args.get('url_',None)[0]
        image_=args.get('imagen',None)[0]
        nombreCanal_ = args.get('nombre', None)[0]
        urlclave = url_

        passwordAes,cadenaEncryptadaB64 =getPassphrase_CadenaEncriptadaB64(urlclave)

        # Determine salt and ciphertext
        #passphrase = bytes(passwordAes, 'utf-8')
        passphrase = passwordAes.encode()
        encryptedData = base64.b64decode(cadenaEncryptadaB64)

        salt = encryptedData[8:16]
        ciphertext = encryptedData[16:]

        # pwd and salt must be bytes objects
        # md5, pwd, salt, key_size, iv_size
        # return key y IV
        # obtenemos key y iv

        #keyIV = openssl_kdf('md5', passphrase, salt, 24, 16)

        keyIV = EVP_BytesToKey(passphrase, salt, 24, 16)

        key = keyIV[0]
        iv = keyIV[1]

        # desencriptamos
        decrypter = Decrypter(AESModeOfOperationCBC(key=key, iv=iv))
        decrypted = decrypter.feed(ciphertext)
        decrypted += decrypter.feed()  # necesario para obtener la totalidad

        print(decrypted.decode('latin-1'))
        #import web_pdb;web_pdb.set_trace()
        urlresult=decrypted.decode('latin-1')+'|Referer=https://embed.latino-web-tv.com/tnt'
        tools.addItemMenu(label=nombreCanal_, thumbnail=image_, url=urlresult, IsPlayable='true', isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)


    if action[0] == 'subcategorias':
        #import web_pdb; web_pdb.set_trace()
        #import YDStreamExtractor
        url_ = args.get('url_',None)[0]

        logger.debug("paso por aqui: " + url_)	
        response = tools.getUrl(url_)
        data = json.loads(response)

        for item in data:
            contentPath = item['contentPath']
            description = item['contentPath']
            thumbnail = domain + "/" + contentPath
            url = domain + "/" + contentPath

            tools.addItemMenu(label = description,thumbnail= thumbnail, url= url, IsPlayable = 'true', isFolder= False)

        xbmcplugin.endOfDirectory(addon_handle)




