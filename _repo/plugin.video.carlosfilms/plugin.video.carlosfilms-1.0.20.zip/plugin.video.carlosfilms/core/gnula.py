# -*- coding: utf-8 -*-
import requests
#from bs4 import BeautifulSoup
import jsbeautifier
import re
import json
from core import logger
from core import tools
from core import httptools
from core import tmdb
import resolveurl

# para nuevos plugins
from plugins import evoloadio
from plugins import gamovideo
from plugins import videossh
from plugins.resolver import Switcher


import xbmcaddon
import xbmc
#import unicodedata
#import urlresolver
#import urllib2

from simpleplugin import Plugin
from time import time
import random

plugin = Plugin()
#with plugin.get_storage() as storage:  # Create a storage object
    #storage['estrenos'] = ""  # Store data
    #value2 = storage['key2']  # Retrieve data




host = "https://www.gnula.nu/"
host_search = "https://cse.google.com/cse/element/v1?rsz=filtered_cse&num=20&hl=es&source=gcsc&gss=.es&sig=c891f6315aacc94dc79953d1f142739e&cx=014793692610101313036:vwtjajbclpq&q=%s&safe=off&cse_tok=%s&googlehost=www.google.com&callback=google.search.Search.csqr6098&nocache=1540313852177&start=0"
item_per_page = 20

IDIOMAS = {'VC':'Esp', 'VL':'Lat', 'VS':'VOSE', 'castellano':'Esp', 'latino':'Lat', 'vose':'VOSE'}

#@plugin.cached(1440)
def get_datospartida():
    listdic=[]
    #import web_pdb;web_pdb.set_trace()
    # __addon__       = xbmcaddon.Addon(id='plugin.video.carlosfilms')
    # __addondir__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ) 

    # path = __addon__.getAddonInfo('path').decode('utf-8')

    imagenestrenos = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/estrenos.jpg").decode('utf-8')
    imagenrecomendadas = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/recomendadas.jpg").decode('utf-8')
    imagengeneros = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/generos.jpg").decode('utf-8')
    imagenbuscar = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/buscar.jpg").decode('utf-8')
    
    #/Users/carlosrentero/Library/Application Support/Kodi/addons/plugin.video.carlosfilms
    #/Users/carlosrentero/Library/Application Support/Kodi/userdata/resources/media/estrenos.png'
    # media= os.path.join(path, 'media')
    # imagenestrenos='estrenos.png'
    # imagenlocal=os.path.join(media, filename.decode('utf-8'))

    opcion1={'urlvalue':host + 'peliculas-online/lista-de-peliculas-online-parte-1/',
          'imagen':imagenestrenos,
          'nombre':'Ultimas películas agregadas','accion':'peliculas'}

    opcion2={'urlvalue':host + 'peliculas-online/lista-de-peliculas-recomendadas/',
          'imagen':imagenrecomendadas,
          'nombre':'Peliculas recomendadas por el servidor','accion':'peliculas'}

    opcion3={'urlvalue':host + 'peliculas-online/lista-de-peliculas-online-parte-1/',
          'imagen':imagenestrenos,
          'nombre':'Películas al azar','accion':'peliculasAleatorias'}

    opcion4={'urlvalue':host + 'generos/lista-de-generos/',
          'imagen':imagengeneros,
          'nombre':'Películas clasificadas por géneros','accion':'generos'}

    opcion5={'urlvalue': host_search,
          'imagen':imagenbuscar,
          'nombre':'Buscar','accion':'searcher'}



    listdic.append(opcion1)
    listdic.append(opcion2)
    listdic.append(opcion3)
    listdic.append(opcion4)
    listdic.append(opcion5)

    return listdic

@plugin.cached(1440)
def getEncuentros(url_,regex):
    start_time = time()
    text=httptools.get_httpdocument(url_)
    elapsed_time = time() - start_time
    xbmc.log('-CARLOSFILMS: duracion get encuentros request sin cache: ' + str(elapsed_time) ,xbmc.LOGINFO)

    start_time = time()
    encuentros = re.findall(regex, text , re.DOTALL)   #[0:3]
    elapsed_time = time() - start_time
    xbmc.log('-CARLOSFILMS: duracion get encuentros  regex sin cache: ' + str(elapsed_time) ,xbmc.LOGINFO)
    return encuentros


def getEncuentrosAleatorios(encuentros, cantidad=20):
    indice = 0
    if encuentros:
        largo = len(encuentros)
        if cantidad > largo:
            return encuentros

        indiceSupMax = largo - cantidad

        if indiceSupMax < 0:
            indiceSupMax = cantidad
            return encuentros[indice:largo-1]

        inicio=random.randint(indice, indiceSupMax-1)
        return encuentros[inicio:inicio+cantidad]


#@plugin.cached(240)
def get_peliculas(url_,posicion=0):
    #import web_pdb;web_pdb.set_trace()
    start_time_completo = time()

    next = True
    itemlistInicial = []
    itemlist = []
    
    regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    start_time = time()

    encuentros = getEncuentros(url_,regex)
    elapsed_time1 = time() - start_time
    xbmc.log('-CARLOSFILMS: duracion get encuentros : ' + str(elapsed_time1) ,xbmc.LOGINFO)

    first = int(posicion)
    last = first + 20

    if last > len(encuentros):
        last = len(encuentros)
        next = False
 
    start_timecompile = time()
    regex = r"href=\"(.*?)\">(.*?)<.*?src=\"(.*?)\".*?\[(.*?)\]\s*\[.*?\">([A-Z\-].*?)<.*?strong>(.*?)$"
    regexUrl = r"href=\"(.*?)\""
    regexTitulo = r"href=\".*?\">(.*?)<"
    regexImagen = r"src=\"(.*?)\""
    regexIdioma = r"\[(.*?)](?:\s|\[)"
    regexCalidad = r"\">([A-Z\\-]+)<"
    regexGeneros = r"<strong>(.*?)$"
    regexYear = r"-(\d{4})-"

    co_regexUrl=re.compile(regexUrl,re.MULTILINE)
    co_regexTitulo=re.compile(regexTitulo,re.MULTILINE)
    co_regexImagen=re.compile(regexImagen,re.MULTILINE)
    co_regexIdioma=re.compile(regexIdioma,re.MULTILINE)
    co_regexCalidad=re.compile(regexCalidad,re.MULTILINE)
    co_regexGeneros=re.compile(regexGeneros,re.MULTILINE)
    co_regexYear=re.compile(regexYear,re.MULTILINE)
    elapsed_timecompile = time() - start_timecompile
    xbmc.log('-CARLOSFILMS: duracion regex compile : ' + str(elapsed_timecompile) ,xbmc.LOGINFO)



    start_timepelis = time()
    encuentros = encuentros[first:last]   # de este modo descargamos la memoria y nos quedamos con el bloque de encuentros que utilizaremos
    for pelis in encuentros:
        item = {}
        try:
            item['url'] = co_regexUrl.findall(pelis)[0]
            item['year'] = co_regexYear.findall(item['url'])[0]
            item['title'] = tools.reemplazos_especiales(co_regexTitulo.findall( pelis )[0])
            item['image'] = co_regexImagen.findall(pelis)[0]
            item['calidad'] = co_regexCalidad.findall(pelis)[0]
            item['genre'] = co_regexGeneros.findall(pelis)[0]
            languages = co_regexIdioma.findall(pelis)[0]
            item['languages'] = get_languages(languages)
            itemlistInicial.append(item)
        except:
            xbmc.log('-CARLOSFILMS: Error pelis en encuentros',xbmc.LOGINFO)

    elapsed_timepelis = time() - start_timepelis
    xbmc.log('-CARLOSFILMS: duracion extraer pelis en encuentros : ' + str(elapsed_timepelis) ,xbmc.LOGINFO)
    xbmc.log('-CARLOSFILMS: pelis en encuentros Extraidas : ' + str(len(itemlistInicial)) ,xbmc.LOGINFO)


    if len(itemlistInicial)>0:
        #import web_pdb;web_pdb.set_trace()
        start_time = time()
    
        datos_completos = tmdb.get_tmdb(itemlistInicial)
        elapsed_time = time() - start_time
        xbmc.log('-CARLOSFILMS: duracion tmdb : ' + str(elapsed_time) ,xbmc.LOGINFO)
        #import web_pdb;web_pdb.set_trace()
        for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url = itemlist_['url']
            titulo_gnula = itemlist_['title']
            image_gnula = itemlist_['image']
            calidad = itemlist_['calidad']
            generos = itemlist_['genre']
            languages = itemlist_['languages']
            year = itemlist_['year']

            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [tools.giveColor(title,'blue',True), str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': generos,
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)


    url_next_page = url_
    first = last

    if next:
        objeto = {'accion' : 'peliculas',
                'contentTitle' : 'Siguiente >>',
                'year' : '',
                'language':'',
                'plot' : '',
                'quality':'',
                'title' : 'Siguiente >>',
                'thumbnail' :'',
                'url' : url_next_page,
                'posicion': first}

    itemlist.append(objeto)
    elapsed_time_completo = time() - start_time_completo
    xbmc.log('-CARLOSFILMS: duracion total get_peliculas: ' + str(elapsed_time_completo) ,xbmc.LOGINFO)

    return itemlist

    # with plugin.get_storage() as storage:
    #     try:
    #         encuentrosestrenos = storage['estrenos']
    #     except:
    #         encuentrosestrenos = None


    # if (encuentrosestrenos == None):
    #     text=httptools.get_httpdocument(url_)
    #     regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    #     encuentros = re.findall( regex, text , re.DOTALL)            #[0:3]
    #     with plugin.get_storage() as storage:
    #         try:
    #             storage['estrenos']= encuentros
    #         except:
    #             encuentrosestrenos = None
        
    # else:
        
    #         encuentros=encuentrosestrenos

def get_peliculasAleatorio(url_):
    #import web_pdb;web_pdb.set_trace()
    start_time_completo = time()

    itemlistInicial = []
    itemlist = []
    
    regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    start_time = time()

    encuentros = getEncuentros(url_,regex)
    encuentros = getEncuentrosAleatorios(encuentros)
    elapsed_time1 = time() - start_time
    xbmc.log('-CARLOSFILMS: duracion get encuentros : ' + str(elapsed_time1) ,xbmc.LOGINFO)
 
    start_timecompile = time()
    regex = r"href=\"(.*?)\">(.*?)<.*?src=\"(.*?)\".*?\[(.*?)\]\s*\[.*?\">([A-Z\-].*?)<.*?strong>(.*?)$"
    regexUrl = r"href=\"(.*?)\""
    regexTitulo = r"href=\".*?\">(.*?)<"
    regexImagen = r"src=\"(.*?)\""
    regexIdioma = r"\[(.*?)](?:\s|\[)"
    regexCalidad = r"\">([A-Z\\-]+)<"
    regexGeneros = r"<strong>(.*?)$"
    regexYear = r"-(\d{4})-"

    co_regexUrl=re.compile(regexUrl,re.MULTILINE)
    co_regexTitulo=re.compile(regexTitulo,re.MULTILINE)
    co_regexImagen=re.compile(regexImagen,re.MULTILINE)
    co_regexIdioma=re.compile(regexIdioma,re.MULTILINE)
    co_regexCalidad=re.compile(regexCalidad,re.MULTILINE)
    co_regexGeneros=re.compile(regexGeneros,re.MULTILINE)
    co_regexYear=re.compile(regexYear,re.MULTILINE)
    elapsed_timecompile = time() - start_timecompile
    xbmc.log('-CARLOSFILMS: duracion regex compile : ' + str(elapsed_timecompile) ,xbmc.LOGINFO)



    start_timepelis = time()
    
    for pelis in encuentros:
        item = {}
        try:
            item['url'] = co_regexUrl.findall(pelis)[0]
            item['year'] = co_regexYear.findall(item['url'])[0]
            item['title'] = tools.reemplazos_especiales(co_regexTitulo.findall( pelis )[0])
            item['image'] = co_regexImagen.findall(pelis)[0]
            item['calidad'] = co_regexCalidad.findall(pelis)[0]
            item['genre'] = co_regexGeneros.findall(pelis)[0]
            languages = co_regexIdioma.findall(pelis)[0]
            item['languages'] = get_languages(languages)
            itemlistInicial.append(item)
        except:
            xbmc.log('-CARLOSFILMS: Error pelis en encuentros',xbmc.LOGINFO)

    elapsed_timepelis = time() - start_timepelis
    xbmc.log('-CARLOSFILMS: duracion extraer pelis en encuentros : ' + str(elapsed_timepelis) ,xbmc.LOGINFO)
    xbmc.log('-CARLOSFILMS: pelis en encuentros Extraidas : ' + str(len(itemlistInicial)) ,xbmc.LOGINFO)


    if len(itemlistInicial)>0:
        #import web_pdb;web_pdb.set_trace()
        start_time = time()
    
        datos_completos = tmdb.get_tmdb(itemlistInicial)
        elapsed_time = time() - start_time
        xbmc.log('-CARLOSFILMS: duracion tmdb : ' + str(elapsed_time) ,xbmc.LOGINFO)
        #import web_pdb;web_pdb.set_trace()
        for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url = itemlist_['url']
            titulo_gnula = itemlist_['title']
            image_gnula = itemlist_['image']
            calidad = itemlist_['calidad']
            generos = itemlist_['genre']
            languages = itemlist_['languages']
            year = itemlist_['year']

            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [tools.giveColor(title,'blue',True), str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': generos,
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)

    elapsed_time_completo = time() - start_time_completo
    xbmc.log('-CARLOSFILMS: duracion total get_peliculas: ' + str(elapsed_time_completo) ,xbmc.LOGINFO)

    return itemlist


@plugin.cached(1440)
def getHtml(url_):
	text=httptools.get_httpdocument(url_)
	return text

@plugin.cached(1440)
def getEncuentrosFromHtml(html,patron):
	matches = re.compile(patron, re.DOTALL).findall(html)
	return matches

@plugin.cached(1440)
def get_generos(url):
    itemlist = []

    # data = httptools.get_httpdocument(url)
    # patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)" title="([^"]+)"'
    # matches = re.compile(patron, re.DOTALL).findall(data)
    data = getHtml(url)
    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)" title="([^"]+)"'
    matches = getEncuentrosFromHtml(data,patron)

    for titulo, url, plot in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url,
                  'plot':plot
                  }
        itemlist.append(objeto)

    # patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)"'
    # matches = re.compile(patron, re.DOTALL).findall(data)

	patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)"'
    matches = getEncuentrosFromHtml(data,patron)
    for titulo, url in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url
                  }
        if url in [it.get('url') for it in itemlist]: continue  # descartar repetidos
        itemlist.append(objeto)

    return sorted(itemlist, key=lambda it: it.get('title'))

#@plugin.cached(1140)
def list_peliculas_generos(url_,posicion=0):
    start_time_completo = time()
    IDIOMAS = {'VC': 'Esp', 'VL': 'Lat', 'VS': 'VOSE', 'castellano': 'Esp', 'latino': 'Lat', 'vose': 'VOSE'}
    itemlist = []
    next = True

    patron = '<a class="Ntooltip" href="([^"]+)">([^<]+)<span><br[^<]+'
    patron += '<img src="([^"]+)"></span></a>(.*?)<br'

    start_time = time()
    matches = getEncuentros(url_,patron)
    elapsed_time = time() - start_time
    xbmc.log('-CARLOSFILMS: duracion getencuentros desde list_peliculas_generos : ' + str(elapsed_time) ,xbmc.LOGINFO)

    

    first = int(posicion)
    last = first + 30

    if last > len(matches):
        last = len(matches)
        next = False

    
    itemlistInicial = []
    matches=matches[first:last]  # de este modo descargamos la memoria y nos quedamos con el bloque de matches que utilizaremos
    
    for urlscraped, title, thumb, resto in matches:
        datosscrapped={}
        # title=unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').upper()
        patron = '-(\d+)-online/$'
        try:
            year = re.compile(patron, re.DOTALL).findall(urlscraped)[0]
        except:
            year = 0
        patron ='<span style="[^"]+">([^<]+)</span>'
        spans = re.compile(patron, re.DOTALL).findall(resto)
        #year = scrapertools.find_single_match(url, '-(\d+)-online/$')
        #spans = scrapertools.find_multiple_matches(resto, '<span style="[^"]+">([^<]+)</span>')
        langs = []
        quality = ''
        for span in spans:
            if span.startswith('(') and span.endswith(')'):
                lg = span[1:-1]
                langs.append(IDIOMAS.get(lg, lg))
            elif len(langs) > 0:
                quality = span
                break
        if langs != None and len(langs)>0:
            lenguages = ','.join(langs)
        else:
            lenguages=''

        title=tools.reemplazos_especiales(title)

        if year > 0:
            title=tools.quitanumerosfinales(title)

        datosscrapped['title'] = tools.reemplazos_especiales(title)
        datosscrapped['url'] = urlscraped
        datosscrapped['year'] = year
        datosscrapped['calidad'] = quality

        datosscrapped['languages'] = lenguages
        #datosscrapped['languages'] = langs
        datosscrapped['image'] = thumb

        itemlistInicial.append(datosscrapped)


    #import web_pdb;web_pdb.set_trace()
    datos_completos = tmdb.get_tmdb(itemlistInicial)   
    #infolabels,actores = tools.imdb_scraper(title,year)
    ####
    for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url = itemlist_['url']
            titulo_gnula = itemlist_['title']
            image_gnula = itemlist_['image']
            calidad = itemlist_['calidad']
            #generos = itemlist_['genre']
            languages = itemlist_['languages']
            year = itemlist_['year']

            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [tools.giveColor(title,'blue',True), str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'languages': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': 'generos',
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)

    url_next_page = url_
    first = last

    if next:
        objeto = {'accion': 'peliculas_generos',
                    'url': url_next_page,
                    'title': 'Siguiente >>',
                    'thumbnail': '',
                    'languages': '',
                    'qualities': '',
                    'year': '',
                    'posicion': first}

        itemlist.append(objeto)

    elapsed_time_completo = time() - start_time_completo
    xbmc.log('-CARLOSFILMS: duracion total list_peliculas_generos: ' + str(elapsed_time_completo) ,xbmc.LOGINFO)
    return itemlist

@plugin.cached(1140)
def findvideos(url_):
    #import web_pdb;web_pdb.set_trace()
    itemlist = []
    data = httptools.get_httpdocument(url_)

    patron = r"<em>(.*?)<\/div><p>"
    bloques_contenedores=tools.find_multiple_matches(data, 'contenedor_tab.*?/table') #revisar
    if bloques_contenedores!=None:
        patron_idioma=r"em>opci.*?,\s*(.*?),"
        lang=tools.find_multiple_matches(data, patron_idioma)
        if lang==None or len(lang)<1:
            patron_idioma = r">Ver pel.*?\[.*?,\s*(.*?),"
            lang=tools.find_multiple_matches(data, patron_idioma)
        bloque=0
        for block in bloques_contenedores:
            patron_videos=r"(?:src|href)=\"(http.*?)\""
            #import web_pdb;web_pdb.set_trace()
            urls_videos=tools.find_multiple_matches(block,patron_videos)
            for url in urls_videos:
                if tools.isDisableServidor(url):continue
                objeto = {'accion' : 'play',
                    'url' : url,
                    'lang' : lang[bloque]
                    }
                itemlist.append(objeto)
            bloque=bloque+1
    else:
        itemlist=findvideos(url)

    return itemlist


class Item:
  def __init__(self, url, age):
    self.url = url
    self.age = age

  def myfunc(self):
    print("Hello my name is " + self.url)



#@plugin.cached(30)
def search_alfa(texto):
    sesion = requests.Session()
    headers = httptools.get_defaultHeaders()
    sesion.headers = headers

    
    item = Item
    texto = texto.replace(" ", "+")

    #data = httptools.get_httpdocument(host)
    req = sesion.get(host)
    data = req.text
    #import web_pdb;web_pdb.set_trace()

    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')
    
    #data = httptools.get_httpdocument("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv)
    req = sesion.get("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv)
    data = req.text

    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:                                       #Evita un loop si error
        item.url = host_search %(texto, cse_token)
        try:
            return sub_search_alfa(item, sesion)
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        except:
            import sys
            for line in sys.exc_info():
                print("%s" % line)
    return []

@plugin.cached(30)
def sub_search_alfa(item,sesion):
    
    import time
    itemlistinicial = []
    itemlist = []
    item_per_page = 20
    while True:
        time.sleep(3)
        #import web_pdb;web_pdb.set_trace()
        #req=httptools.get_request(item.url)
        req = sesion.get(item.url)
        if req.status_code != 200:
            return

        data = req.text
        
        if len(data) < 500 :      #Evita un loop si error
            break

        import web_pdb;web_pdb.set_trace()
        page = int(tools.find_single_match(item.url, ".*?start=(\d+)")) + item_per_page
        item.url = tools.find_single_match(item.url, "(.*?start=)") + str(page)
        patron =  '(?s)clicktrackUrl":\s*".*?q=(.*?)".*?'
        patron += 'titleNoFormatting":\s*"([^"]+)".*?'
        patron += 'cseThumbnail.*?"src":\s*"([^"]+)"' # se usa el thumb de google

        matches = tools.find_multiple_matches(data, patron)
        xbmc.log('-CARLOSFILMS: sub_search_alfa: EMPIEZA BUCLE FOR SOBRE MATCHES ENCONTRADOS' + str(len(matches)) ,xbmc.LOGINFO)
        for scrapedurl, scrapedtitle, scrapedthumbnail in matches:
            xbmc.log('-CARLOSFILMS: sub_search_alfa: ' + scrapedurl ,xbmc.LOGINFO)
            scrapedurl = tools.find_single_match(scrapedurl, ".*?online/")
            scrapedtitle = scrapedtitle.replace(" online", "").replace("<b>", "").replace("</b>", "")
            if "ver-" not in scrapedurl:
                continue
            xbmc.log('-CARLOSFILMS: sub_search_alfa: ' + scrapedtitle ,xbmc.LOGINFO)
            year = tools.find_single_match(scrapedtitle, "\d{4}")
            contentTitle = scrapedtitle.replace(tools.find_single_match('\[.+', scrapedtitle),"")
            contentTitle = scrapedtitle.replace("(%s)" %year,"").replace("Ver","").strip()
            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'language',
                    'plot' : 'plot',
                    'quality':'quality',
                    'title' : contentTitle,           #scrapedtitle,
                    'thumbnail' :scrapedthumbnail,
                    'url' : scrapedurl,
                    'genre': 'genre'
                    }
            itemlistinicial.append(objeto)
    import web_pdb;web_pdb.set_trace()
    if len(itemlistinicial) > 0:
        #import web_pdb;web_pdb.set_trace()
        datos_completos=tmdb.get_tmdb(itemlistinicial)
        for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url_gnula = itemlist_['url']
            titulo_gnula = itemlist_['title']
            year = itemlist_['year']
            thumbnail_gnula = itemlist_['thumbnail']


            tituloespanol = infolabels.get('title')
            poster_path = infolabels.get('poster_path')
            plot = infolabels.get('plot')

            puntuacion = infolabels.get('rating')

            if tituloespanol:
                titulo = tituloespanol
            else:
                titulo = titulo_gnula

            if poster_path:
                thumbnail = poster_path
            else:
                thumbnail = thumbnail_gnula


            if puntuacion and puntuacion is not '':
                separator = ' - '
                contentlist = [tools.giveColor(titulo,'blue',True) , str(year) , 'Puntuacion: ' + str(puntuacion)]
                contentTitle = separator.join(contentlist).replace("'", "")
                #contentTitle = (titulo + ' - ' + str(year) + ' (' + str(puntuacion) + ')').replace("'", "")
            else:
                separator = ' - '
                contentlist = [tools.giveColor(titulo,'blue',True) , str(year)]
                contentTitle = separator.join(contentlist).replace("'", "")
                #contentTitle = (titulo + ' - ' + str(year)).replace("'", "")

            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'',
                    'plot' : plot,
                    'quality':'',
                    'title' : titulo,           #scrapedtitle,
                    'thumbnail' :thumbnail,
                    'url' : url_gnula,
                    'genre': '',
                    'infolabels': infolabels,
                    'actores': actores
                    }
            itemlist.append(objeto)

    return itemlist

    
@plugin.cached(30)
def get_link(urldada):
        #import web_pdb;web_pdb.set_trace()
        hmf = resolveurl.HostedMediaFile(url=urldada)
        if not hmf:
            motivo = 'Servidor aun no soportado:[CR]%s' % tools.get_dominio(url=urldada,lang='')
            motivoresolveUrl=motivo
            #tools.notify('Link no soportado: %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
            resolved=False
        else:
            try:
                resolved = resolveurl.resolve(urldada)
                motivo = ''
                #resolved2 = urlresolver.resolve(urldada)
            except:
                motivo = 'Pelicula borrada del servidor:[CR]%s' % tools.get_dominio(url=urldada,lang='')
                motivoresolveUrl=motivo
                #tools.notify('Pelicula borrada del servidor : %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
                xbmc.log("ERROR RESOLVER ADDON: " + urldada)
                resolved = False

        if resolved == False:
            
            resolved = Switcher(urldada).get_server()
            if 'http' not in resolved:
                motivo =  motivoresolveUrl
                resolved = False
        
        if resolved == False:
            tools.notify(motivo,duration=200)
        return resolved

#@plugin.cached(30)
def get_languages(valores):
    regex = r"\((V[A-Z].*?)\)"
    language = []
    result = ''
    languages = re.findall(regex, valores, re.DOTALL)
    if len(languages)>0:
        for lang in languages:
            langu = IDIOMAS.get(lang, lang)
            language.append(langu)
        language = sorted(language)
        result=','.join(language)
    return result



