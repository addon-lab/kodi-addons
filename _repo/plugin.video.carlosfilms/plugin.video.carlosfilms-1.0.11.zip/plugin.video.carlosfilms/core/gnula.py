# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import jsbeautifier
import re
import json
from core import logger
from core import tools
from core import httptools
from core import tmdb
import resolveurl
import xbmcaddon
import xbmc
#import unicodedata
import urlresolver
#import urllib2

host = "https://www.gnula.nu/"
host_search = "https://cse.google.com/cse/element/v1?rsz=filtered_cse&num=20&hl=es&source=gcsc&gss=.es&sig=c891f6315aacc94dc79953d1f142739e&cx=014793692610101313036:vwtjajbclpq&q=%s&safe=off&cse_tok=%s&googlehost=www.google.com&callback=google.search.Search.csqr6098&nocache=1540313852177&start=0"
item_per_page = 20

IDIOMAS = {'VC':'Esp', 'VL':'Lat', 'VS':'VOSE', 'castellano':'Esp', 'latino':'Lat', 'vose':'VOSE'}


def get_datospartida():
    listdic=[]
    #import web_pdb;web_pdb.set_trace()
    # __addon__       = xbmcaddon.Addon(id='plugin.video.carlosfilms')
    # __addondir__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ) 

    # path = __addon__.getAddonInfo('path').decode('utf-8')

    imagenestrenos = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/estrenos.png").decode('utf-8')
    imagenrecomendadas = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/recomendadas.jpg").decode('utf-8')
    imagengeneros = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/generos.png").decode('utf-8')
    imagenbuscar = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/buscar.png").decode('utf-8')
    
    #/Users/carlosrentero/Library/Application Support/Kodi/addons/plugin.video.carlosfilms
    #/Users/carlosrentero/Library/Application Support/Kodi/userdata/resources/media/estrenos.png'
    # media= os.path.join(path, 'media')
    # imagenestrenos='estrenos.png'
    # imagenlocal=os.path.join(media, filename.decode('utf-8'))

    opcion1={'urlvalue':host + 'peliculas-online/lista-de-peliculas-online-parte-1/',
          'imagen':imagenestrenos,
          'nombre':'Estrenos','accion':'peliculas'}

    opcion2={'urlvalue':host + 'peliculas-online/lista-de-peliculas-recomendadas/',
          'imagen':imagenrecomendadas,
          'nombre':'Recomendadas','accion':'peliculas'}

    opcion3={'urlvalue':host + 'generos/lista-de-generos/',
          'imagen':imagengeneros,
          'nombre':'Generos','accion':'generos'}

    opcion4={'urlvalue': host_search,
          'imagen':imagenbuscar,
          'nombre':'Buscar','accion':'searcher'}

    listdic.append(opcion1)
    listdic.append(opcion2)
    listdic.append(opcion3)
    listdic.append(opcion4)

    return listdic

def get_peliculas(url_,posicion=0):
    next = True
    itemlistInicial = []
    itemlist = []
    text=httptools.get_link(url_)
    regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    encuentros = re.findall( regex, text , re.DOTALL)            #[0:3]

    first = int(posicion)
    last = first + 10

    if last > len(encuentros):
        last = len(encuentros)
        next = False
 

    regex = r"href=\"(.*?)\">(.*?)<.*?src=\"(.*?)\".*?\[(.*?)\]\s*\[.*?\">([A-Z\-].*?)<.*?strong>(.*?)$"
    regexUrl = r"href=\"(.*?)\""
    regexTitulo = r"href=\".*?\">(.*?)<"
    regexImagen = r"src=\"(.*?)\""
    regexIdioma = r"\[(.*?)](?:\s|\[)"
    regexCalidad = r"\">([A-Z\\-]+)<"
    regexGeneros = r"<strong>(.*?)$"
    regexYear = r"-(\d{4})-"
    
    for pelis in encuentros[first:last]:
        item = {}
        try:
            item['url'] = re.findall( regexUrl , pelis , re.MULTILINE)[0]
            item['year'] = re.findall(regexYear, item['url'], re.MULTILINE)[0]
            item['title'] = tools.reemplazos_especiales(re.findall( regexTitulo , pelis , re.MULTILINE)[0])
            item['image'] = re.findall( regexImagen, pelis, re.MULTILINE)[0]
            item['calidad'] = re.findall(regexCalidad, pelis, re.MULTILINE)[0]
            item['genre'] = re.findall(regexGeneros, pelis, re.MULTILINE)[0]
            languages = re.findall(regexIdioma,pelis, re.MULTILINE)[0]
            item['languages'] = get_languages(languages)
            itemlistInicial.append(item)
        except:
            print('error pelis')

    if len(itemlistInicial)>0:
        for item in itemlistInicial:
            url = item['url']
            titulo_gnula = item['title']
            image_gnula = item['image']
            calidad = item['calidad']
            generos = item['genre']
            languages = item['languages']
            year = item['year']
            infolabels, actores = tmdb.imdb_scraper(item.get('title'), item.get('year'))
            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [title, str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': generos,
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)


    url_next_page = url_
    first = last

    if next:
        objeto = {'accion' : 'peliculas',
                'contentTitle' : 'Siguiente >>',
                'year' : '',
                'language':'',
                'plot' : '',
                'quality':'',
                'title' : 'Siguiente >>',
                'thumbnail' :'',
                'url' : url_next_page,
                'posicion': first}

    itemlist.append(objeto)

    objeto = {'accion' : 'Inicio',
                'nombre' : 'Inicio',
                'imagen' :'',
                'url' : ''
                }
    itemlist.append(objeto)


    #     itemlist.append(item.clone(title="Siguiente >>", url=url_next_page, action='peliculas', first=first))

    return itemlist

def get_generos(url):
    itemlist = []
    data = httptools.get_link(url)

    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)" title="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)
    for titulo, url, plot in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url,
                  'plot':plot
                  }
        itemlist.append(objeto)

    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)
    for titulo, url in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url
                  }
        if url in [it.get('url') for it in itemlist]: continue  # descartar repetidos
        itemlist.append(objeto)

    return sorted(itemlist, key=lambda it: it.get('title'))

def list_peliculas_generos(url,posicion=0):
    IDIOMAS = {'VC': 'Esp', 'VL': 'Lat', 'VS': 'VOSE', 'castellano': 'Esp', 'latino': 'Lat', 'vose': 'VOSE'}
    itemlist = []
    next = True

    data = text=httptools.get_link(url)

    patron = '<a class="Ntooltip" href="([^"]+)">([^<]+)<span><br[^<]+'
    patron += '<img src="([^"]+)"></span></a>(.*?)<br'
    matches = re.compile(patron, re.DOTALL).findall(data)

    first = int(posicion)
    last = first + 10

    if last > len(matches):
        last = len(matches)
        next = False


    for urlscraped, title, thumb, resto in matches[first:last]:
        # title=unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').upper()
        patron = '-(\d+)-online/$'
        try:
            year = re.compile(patron, re.DOTALL).findall(url)[0]
        except:
            year = 0
        patron ='<span style="[^"]+">([^<]+)</span>'
        spans = re.compile(patron, re.DOTALL).findall(resto)
        #year = scrapertools.find_single_match(url, '-(\d+)-online/$')
        #spans = scrapertools.find_multiple_matches(resto, '<span style="[^"]+">([^<]+)</span>')
        langs = []
        quality = ''
        for span in spans:
            if span.startswith('(') and span.endswith(')'):
                lg = span[1:-1]
                langs.append(IDIOMAS.get(lg, lg))
            elif len(langs) > 0:
                quality = span
                break
        
        infolabels,actores = tools.imdb_scraper(title,year)
        tituloespanol=infolabels.get('title')
        poster_path=infolabels.get('poster_path')

        if tituloespanol!= None:
            title=tituloespanol

        if poster_path!= None:
            thumb=poster_path


        objecto={ 'accion':'findvideos',
                  'url':urlscraped,
                  'title':title,
                  'thumbnail':thumb,
                  'languages':', '.join(langs),
                  'qualities':quality,
                  'year': year,
                  'infolabels': infolabels,
                  'actores': actores
        }

        itemlist.append(objecto)

    url_next_page = url
    first = last

    if next:
        objeto = {'accion': 'peliculas_generos',
                    'url': url_next_page,
                    'title': 'Siguiente >>',
                    'thumbnail': '',
                    'languages': '',
                    'qualities': '',
                    'year': '',
                    'posicion': first}

        itemlist.append(objeto)

    
    return itemlist

def findvideos(url_):
    #import web_pdb;web_pdb.set_trace()
    itemlist = []
    data = httptools.get_link(url_)

    patron = r"<em>(.*?)<\/div><p>"
    bloques_contenedores=tools.find_multiple_matches(data, 'contenedor_tab.*?/table') #revisar
    if bloques_contenedores!=None:
        patron_idioma=r"em>opci.*?,\s*(.*?),"
        lang=tools.find_multiple_matches(data, patron_idioma)
        if lang==None or len(lang)<1:
            patron_idioma = r">Ver pel.*?\[.*?,\s*(.*?),"
            lang=tools.find_multiple_matches(data, patron_idioma)
        bloque=0
        for block in bloques_contenedores:
            patron_videos=r"(?:src|href)=\"(http.*?)\""
            #import web_pdb;web_pdb.set_trace()
            urls_videos=tools.find_multiple_matches(block,patron_videos)
            for url in urls_videos:
                if tools.isDisableServidor(url):continue
                objeto = {'accion' : 'play',
                    'url' : url,
                    'lang' : lang[bloque]
                    }
                itemlist.append(objeto)
            bloque=bloque+1
    else:
        itemlist=findvideos(url)

    return itemlist

def search(texto):
    
    texto = texto.replace(" ", "+")
    item = Item
    
    req=requests.get(host)
    #import web_pdb;web_pdb.set_trace()
    if req.status_code != 200:
        return
    
    data=req.text
    ##data = httptools.downloadpage(host).data
    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')

    req=requests.get("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv)
    #import web_pdb;web_pdb.set_trace()
    if req.status_code != 200:
        return
    
    data=req.text

    #data = httptools.downloadpage("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv).data
    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:                                       #Evita un loop si error
        item.url = host_search %(texto, cse_token)
        try:
            return sub_search(item)
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        except:
            import sys
            for line in sys.exc_info():
                print("%s" % line)
    return []


def sub_search(item):
    #import web_pdb;web_pdb.set_trace()
    itemlist = []
    item_per_page=50
    while True:
        req=requests.get(item.url)
        if req.status_code != 200:
            return
    
        data=req.text
        if len(data) < 500:      #Evita un loop si error
            break

        page = int(tools.find_single_match(item.url, ".*?start=(\d+)")) + item_per_page
        item.url = tools.find_single_match(item.url, "(.*?start=)") + str(page)
        patron =  '(?s)clicktrackUrl":\s*".*?q=(.*?)".*?'
        patron += 'titleNoFormatting":\s*"([^"]+)".*?'
        patron += 'cseThumbnail.*?"src":\s*"([^"]+)"' # se usa el thumb de google
        matches = tools.find_multiple_matches(data, patron)
        for scrapedurl, scrapedtitle, scrapedthumbnail in matches:
            scrapedurl = tools.find_single_match(scrapedurl, ".*?online/")
            scrapedtitle = scrapedtitle.replace(" online", "").replace("<b>", "").replace("</b>", "")
            if "ver-" not in scrapedurl:
                continue
            year = tools.find_single_match(scrapedtitle, "\d{4}")
            title= tools.find_single_match(scrapedurl, r"Ver\s*(.*?)\s*\(\d*")
            contentTitle = scrapedtitle.replace(tools.find_single_match('\[.+', scrapedtitle),"")
            contentTitle = scrapedtitle.replace("(%s)" %year,"").replace("Ver","").strip()


            #contentTitle = (scrapedtitle + ' - ' + str(language) + ' - ' + str(year) + ' - ' + genre).replace("'","")
            infolabels,actores = tools.imdb_scraper(title,year)
            tituloespanol=infolabels.get('title')
            poster_path=infolabels.get('poster_path')

            if tituloespanol!= None:
                title=tituloespanol

            if poster_path!= None:
                thumb=poster_path


            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'language',
                    'plot' : 'plot',
                    'quality':'quality',
                    'title' : tituloespanol,           #scrapedtitle,
                    'thumbnail' :scrapedthumbnail,
                    'url' : scrapedurl,
                    'genre': 'genre',
                    'infolabels': infolabels,
                    'actores': actores}
            # itemlist.append(Item(action = "findvideos",
            #                      channel = item.channel,
            #                      contentTitle = contentTitle,
            #                      infoLabels = {"year":year},
            #                      title = scrapedtitle,
            #                      thumbnail = scrapedthumbnail,
            #                      url = scrapedurl,
            #                      ))

        itemlist.append(objeto)
    
    return itemlist

class Item:
  def __init__(self, url, age):
    self.url = url
    self.age = age

  def myfunc(self):
    print("Hello my name is " + self.url)



def get_link(urldada):
        #import web_pdb;web_pdb.set_trace()
        hmf = resolveurl.HostedMediaFile(url=urldada)
        if not hmf:
            tools.notify('Link no soportado: %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
            resolved=False
        else:
            try:
                resolved = resolveurl.resolve(urldada)
                #resolved2 = urlresolver.resolve(urldada)
            except:
                tools.notify('Pelicula borrada del servidor : %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
                xbmc.log("ERROR RESOLVER ADDON: " + urldada)
                resolved = False
        return resolved

def search2(texto):
    texto = texto.replace(" ", "+")
    item = Item

    default_headers = default_headers_sin_ua
    default_headers[
        'User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 OPR/73.0.3856.284'
    req = urllib2.Request(host, None, default_headers)
    data = urllib2.urlopen(req).read()

    # req = requests.get(host)
    import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return
    #
    # data = req.text
    ##data = httptools.downloadpage(host).data
    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')

    # req = requests.get("https://cse.google.es/cse.js?hpg=1&cx=%s" % cxv)
    # # import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return
    #
    # data = req.text

    req = urllib2.Request("https://cse.google.es/cse.js?hpg=1&cx=%s" % cxv, None, default_headers)
    data = urllib2.urlopen(req).read()

    # data = httptools.downloadpage("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv).data
    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:  # Evita un loop si error
        item.url = host_search % (texto, cse_token)
        #try:
        resultados =sub_search2(item)
        return resultados
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        # except:
        #     import sys
        #     for line in sys.exc_info():
        #         print("%s" % line)
    return []


def sub_search2(itembusqueda):
    import web_pdb;web_pdb.set_trace()
    global objeto
    itemlist = []
    item_per_page = 50
    data= httptools.get_link(itembusqueda.url)

    if len(data) < 500:  return # Evita un loop si error
        #break
    patrongetjson=r'.*?google\.search\.S.*?\((.*?)\);'
    jsontext=tools.find_single_match(data,patrongetjson)
    #aqui tenemos los resultados

    json_data = json.loads(jsontext)
    resultCount=int(json_data['cursor'].get('resultCount'))
    paginaactual=int(json_data['cursor'].get('currentPageIndex'))
    result=json_data['results']
    #return result
    for item in result:
        plot=item['contentNoFormatting']
        title = item['title'].replace(" online", "")
        if 'Lista de Peliculas' in title:continue
        url = item['url']
        year = tools.find_single_match(title, "\d{4}")
        title=title.replace('('+year+')',"")
        if '|' in title:
            regex = r"(.*?)\|"
            title=tools.find_single_match(title,regex)
        title=title.replace('Ver ','').strip()
        title=tools.htmlclean(title)

        scrapedthumbnail=item['richSnippet']['cseThumbnail']['src']
        try:
            genre=item['breadcrumbUrl']['crumbs'][0]
        except:
            genre=''

        contentTitle = (title + ' - ' + str(year)).replace("'", "")
        infolabels, actores = tools.imdb_scraper(title, year)
        if (infolabels != None and len(infolabels)> 0):
            # respuesta["plot"] = plot
            # respuesta["id"] = id
            # respuesta["votes"] = votes
            # respuesta["title"] = title
            # respuesta["rating"] = rating
            # respuesta["aired"] = aired
            # respuesta["poster_path"] = poster_path
            # respuesta["castandrole"] = castandrole

            # actoressetcast["name"]=name
            # actoressetcast["role"]=role
            # actoressetcast["thumbnail"]=thumbnail
            # actoressetcast["order"]=order


            tituloespanol = infolabels.get('title')
            poster_path = infolabels.get('poster_path')
            contentTitle = (title + ' - ' + str(year) ).replace("'", "")

            if tituloespanol != None or tituloespanol !='':
                title = tituloespanol

            if poster_path != None or poster_path !='':
                scrapedthumbnail = poster_path

        objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': 'language',
                      'plot': plot,
                      'quality': 'quality',
                      'title': title,  # scrapedtitle,
                      'thumbnail': scrapedthumbnail,
                      'url': url,
                      'genre': genre,
                      'infolabels': infolabels,
                      'actores': actores}
            # itemlist.append(Item(action = "findvideos",
            #                      channel = item.channel,
            #                      contentTitle = contentTitle,
            #                      infoLabels = {"year":year},
            #                      title = scrapedtitle,
            #                      thumbnail = scrapedthumbnail,
            #                      url = scrapedurl,
            #                      ))

        itemlist.append(objeto)

    return itemlist

def get_languages(valores):
    regex = r"\((V[A-Z].*?)\)"
    language = []
    result = ''
    languages = re.findall(regex, valores, re.DOTALL)
    if len(languages)>0:
        for lang in languages:
            langu = IDIOMAS.get(lang, lang)
            language.append(langu)
        language = sorted(language)
        result=','.join(language)
    return result

def search_alfa(texto):
    item = Item
    texto = texto.replace(" ", "+")
    data = httptools.get_link(host)
    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')
    data = httptools.get_link("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv)
    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:                                       #Evita un loop si error
        item.url = host_search %(texto, cse_token)
        try:
            return sub_search_alfa(item)
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        except:
            import sys
            for line in sys.exc_info():
                print("%s" % line)
    return []


def sub_search_alfa(item):
    
    itemlist = []
    while True:
        data = httptools.get_link(item.url)
        
        if len(data) < 500 :      #Evita un loop si error
            break

        page = int(tools.find_single_match(item.url, ".*?start=(\d+)")) + item_per_page
        item.url = tools.find_single_match(item.url, "(.*?start=)") + str(page)
        patron =  '(?s)clicktrackUrl":\s*".*?q=(.*?)".*?'
        patron += 'titleNoFormatting":\s*"([^"]+)".*?'
        patron += 'cseThumbnail.*?"src":\s*"([^"]+)"' # se usa el thumb de google
        matches = tools.find_multiple_matches(data, patron)
        for scrapedurl, scrapedtitle, scrapedthumbnail in matches:
            scrapedurl = tools.find_single_match(scrapedurl, ".*?online/")
            scrapedtitle = scrapedtitle.replace(" online", "").replace("<b>", "").replace("</b>", "")
            if "ver-" not in scrapedurl:
                continue
            year = tools.find_single_match(scrapedtitle, "\d{4}")
            contentTitle = scrapedtitle.replace(tools.find_single_match('\[.+', scrapedtitle),"")
            contentTitle = scrapedtitle.replace("(%s)" %year,"").replace("Ver","").strip()
            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'language',
                    'plot' : 'plot',
                    'quality':'quality',
                    'title' : scrapedtitle,           #scrapedtitle,
                    'thumbnail' :scrapedthumbnail,
                    'url' : scrapedurl,
                    'genre': 'genre'
                    }
            itemlist.append(objeto)
    
    return itemlist


