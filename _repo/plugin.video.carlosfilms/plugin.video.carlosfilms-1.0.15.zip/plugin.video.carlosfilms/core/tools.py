# -*- coding: utf-8 -*-

import logger
import xbmcaddon
import re
import urllib2
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import sys
#import urllib
import xbmc
import sys
import requests
import unicodedata
import json
from random import randint


PY3 = False
if sys.version_info[0] >= 3: PY3 = True; unicode = str; unichr = chr; long = int

if PY3:
    import urllib.parse as urlparse                             # Es muy lento en PY2.  En PY3 es nativo
    import urllib.parse as urllib
else:
    import urllib                                               # Usamos el nativo de PY2 que es más rápido
    import urlparse

from HTMLParser import HTMLParser

default_headers_sin_ua = dict()
default_headers_sin_ua["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
default_headers_sin_ua["Accept-Language"] = "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3"
default_headers_sin_ua["Accept-Charset"] = "UTF-8"
default_headers_sin_ua["Accept-Encoding"] = "inflate"

def reemplazos_especiales(texto):
    texto=texto.replace('&#8217;',"'")
    texto = texto.replace('&#8211;', "&")
    return texto
def quitanumerosfinales(texto):
    regex = r"(\s*\d*)$"
    subst = ""
    result = re.sub(regex, subst, texto, 0, re.MULTILINE)
    return result
    

def getSetting(settingName):
    setting=xbmcaddon.Addon().getSetting(settingName)
        
    return setting

def getUrl(url):
    #logger.debug(url)

    f=urllib2.urlopen(url)
    data=f.read()
    f.close()

    return data

def findall(pattern, searText, flags):
    #logger.debug("findall - pattern: {0}".format(pattern))

    try:

        return re.findall(pattern, searText,flags)

    except Exception as e:
        logger.debug(str(e))
        return None

def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""


# Parse string and extracts multiple matches using regular expressions
def find_multiple_matches(text, pattern):
    return re.findall(pattern, text, re.DOTALL)



def setView(content, viewType):
        
    if viewType == 'Info':
        VT = '504'
    elif viewType == 'Info2':
        VT = '503'
    elif viewType == 'Info3':
        VT = '515'
    elif viewType == 'Fanart':
        VT = '508'
    elif viewType == 'PosterWrap':
        VT = '501'
    elif viewType == 'BigList':
        VT = '51'
    elif viewType == 'IconWall':
        VT = '52'
    elif viewType == 'WideList':
        VT = '499'            
    elif viewType == 'default-view':
        VT = addon.get_setting(viewType)
                
    xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )



def build_url(query):
    base_url = sys.argv[0]
    params={}
    
    for key in query:
        valor = query[key]
        if isinstance(valor, unicode):
            valor =unicodedata.normalize('NFKD', valor).encode('ASCII', 'ignore')
            query[key]=valor.encode('utf-8')
    params = urllib.urlencode(query)
    return base_url + '?' + params

# def build_url(query):
#     import web_pdb;web_pdb.set_trace()
#     base_url = sys.argv[0]
#     return base_url + '?' + urllib.urlencode(query)

# def build_url(query):

#     base_url = sys.argv[0]
#     newquery=unicodedata.normalize('NFKD', query).encode('ASCII', 'ignore')

#     return base_url + '?' + urllib.urlencode(newquery)

def entityunescape(cadena):
    return unescape(cadena)


def unescape(text):
    """Removes HTML or XML character references
       and entities from a text string.
       keep &amp;, &gt;, &lt; in the source code.
    from Fredrik Lundh
    http://effbot.org/zone/re-sub.htm#unescape-html
    """

    def fixup(m):
        text = m.group(0)
        if text[:2] == "&#":
            # character reference
            try:
                if text[:3] == "&#x":
                    text = unichr(int(text[3:-1], 16)).encode("utf-8")
                else:
                    text = unichr(int(text[2:-1])).encode("utf-8")
                if PY3 and isinstance(text, bytes):
                    text = text.decode("utf-8")
                return text

            except ValueError:
                logger.error("error de valor")
                pass
        else:
            # named entity
            try:
                if PY3:
                    import html.entities as htmlentitydefs
                else:
                    import htmlentitydefs
                text = unichr(htmlentitydefs.name2codepoint[text[1:-1]]).encode("utf-8")
                if PY3 and isinstance(text, bytes):
                    text = text.decode("utf-8")
            except KeyError:
                logger.error("keyerror")
                pass
            except:
                pass
        return text  # leave as is

    return re.sub("&#?\w+;", fixup, str(text))

    # Convierte los codigos html "&ntilde;" y lo reemplaza por "ñ" caracter unicode utf-8


def entitiesfix(string):
    # Las entidades comienzan siempre con el símbolo & , y terminan con un punto y coma ( ; ).
    string = string.replace("&aacute", "&aacute;")
    string = string.replace("&eacute", "&eacute;")
    string = string.replace("&iacute", "&iacute;")
    string = string.replace("&oacute", "&oacute;")
    string = string.replace("&uacute", "&uacute;")
    string = string.replace("&Aacute", "&Aacute;")
    string = string.replace("&Eacute", "&Eacute;")
    string = string.replace("&Iacute", "&Iacute;")
    string = string.replace("&Oacute", "&Oacute;")
    string = string.replace("&Uacute", "&Uacute;")
    string = string.replace("&uuml", "&uuml;")
    string = string.replace("&Uuml", "&Uuml;")
    string = string.replace("&ntilde", "&ntilde;")
    string = string.replace("&#191", "&#191;")
    string = string.replace("&#161", "&#161;")
    string = string.replace(";;", ";")
    #string = string.replace("&#8217;", "'")
    string = HTMLParser().unescape(string)
    return string


def htmlclean(cadena):
    cadena = re.compile("<!--.*?-->", re.DOTALL).sub("", cadena)

    cadena = cadena.replace("<center>", "")
    cadena = cadena.replace("</center>", "")
    cadena = cadena.replace("<cite>", "")
    cadena = cadena.replace("</cite>", "")
    cadena = cadena.replace("<em>", "")
    cadena = cadena.replace("</em>", "")
    cadena = cadena.replace("<u>", "")
    cadena = cadena.replace("</u>", "")
    cadena = cadena.replace("<li>", "")
    cadena = cadena.replace("</li>", "")
    cadena = cadena.replace("<turl>", "")
    cadena = cadena.replace("</tbody>", "")
    cadena = cadena.replace("<tr>", "")
    cadena = cadena.replace("</tr>", "")
    cadena = cadena.replace("<![CDATA[", "")
    cadena = cadena.replace("<wbr>", "")
    cadena = cadena.replace("<Br />", " ")
    cadena = cadena.replace("<BR />", " ")
    cadena = cadena.replace("<Br>", " ")
    cadena = re.compile("<br[^>]*>", re.DOTALL).sub(" ", cadena)

    cadena = re.compile("<script.*?</script>", re.DOTALL).sub("", cadena)

    cadena = re.compile("<option[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</option>", "")

    cadena = re.compile("<button[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</button>", "")

    cadena = re.compile("<i[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</iframe>", "")
    cadena = cadena.replace("</i>", "")

    cadena = re.compile("<table[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</table>", "")

    cadena = re.compile("<td[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</td>", "")

    cadena = re.compile("<div[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</div>", "")

    cadena = re.compile("<dd[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</dd>", "")

    cadena = re.compile("<b[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</b>", "")

    cadena = re.compile("<font[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</font>", "")

    cadena = re.compile("<strong[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</strong>", "")

    cadena = re.compile("<small[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</small>", "")

    cadena = re.compile("<span[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</span>", "")

    cadena = re.compile("<a[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</a>", "")

    cadena = re.compile("<p[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</p>", "")

    cadena = re.compile("<ul[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</ul>", "")

    cadena = re.compile("<h1[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</h1>", "")

    cadena = re.compile("<h2[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</h2>", "")

    cadena = re.compile("<h3[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</h3>", "")

    cadena = re.compile("<h4[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</h4>", "")

    cadena = re.compile("<!--[^-]+-->", re.DOTALL).sub("", cadena)

    cadena = re.compile("<img[^>]*>", re.DOTALL).sub("", cadena)

    cadena = re.compile("<object[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</object>", "")
    cadena = re.compile("<param[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</param>", "")
    cadena = re.compile("<embed[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</embed>", "")

    cadena = re.compile("<title[^>]*>", re.DOTALL).sub("", cadena)
    cadena = cadena.replace("</title>", "")

    cadena = re.compile("<link[^>]*>", re.DOTALL).sub("", cadena)

    cadena = cadena.replace("\t", "")
    cadena = entityunescape(cadena)
    return cadena

def reemplazosEspeciales(cadena):
    
    cadena = cadena.replace("\xc3\xba", "u")

    cadena = cadena.replace('\xc3\xa0','a')
    cadena = cadena.replace('\xc3\xa1','a')
    cadena = cadena.replace('\xc3\xa2','a')
    cadena = cadena.replace('\xc3\xa3','a')
    cadena = cadena.replace('\xc3\xa4','a')
    cadena = cadena.replace('\xc3\xa5','a')

    cadena = cadena.replace('\xc3\xa8','e')
    cadena = cadena.replace('\xc3\xa9','e')
    cadena = cadena.replace('\xc3\xaa','e')
    cadena = cadena.replace('\xc3\xab','e')

    cadena = cadena.replace('\xc3\xad','i')
    cadena = cadena.replace('\xc3\xae','i')
    cadena = cadena.replace('\xc3\xaf','i')

    cadena = cadena.replace('\xc3\xb2','o')
    cadena = cadena.replace('\xc3\xb3','o')
    cadena = cadena.replace('\xc3\xb4','o')
    cadena = cadena.replace('\xc3\xb5','o')
    cadena = cadena.replace('\xc3\xb6','o')

    cadena = cadena.replace('\xc3\xb9','u')
    cadena = cadena.replace('\xc3\xba','u')
    cadena = cadena.replace('\xc3\xbb','u')
    cadena = cadena.replace('\xc3\xbc','u')


    cadena = cadena.replace('\xc3\x80','A')
    cadena = cadena.replace('\xc3\x81','a')
    cadena = cadena.replace('\xc3\x82','A')
    cadena = cadena.replace('\xc3\x83','a')
    cadena = cadena.replace('\xc3\x84','A')
    cadena = cadena.replace('\xc3\x85','a')

    cadena = cadena.replace('\xc4\x8c','C')
    cadena = cadena.replace('\xc4\x8d','c')

    cadena = cadena.replace('\xc4\x8e','D')
    cadena = cadena.replace('\xc4\x8f','d')
    cadena = cadena.replace('\xc4\x90','D')
    cadena = cadena.replace('\xc4\x91','d')

    cadena = cadena.replace('\xc4\x92','E')
    cadena = cadena.replace('\xc4\x93','e')
    cadena = cadena.replace('\xc4\x94','E')
    cadena = cadena.replace('\xc4\x95','e')
    cadena = cadena.replace('\xc4\x96','E')
    cadena = cadena.replace('\xc4\x97','e')
    cadena = cadena.replace('\xc4\x98','E')
    cadena = cadena.replace('\xc4\x99','e')
    cadena = cadena.replace('\xc4\x9a','E')
    cadena = cadena.replace('\xc4\x9b','e')
    cadena = cadena.replace("\xc3\x89","E")
    cadena = cadena.replace("\xc3\x8a","E")
    cadena = cadena.replace("\xc3\x8b","E")

    cadena = cadena.replace('\xc4\x9c','G')
    cadena = cadena.replace('\xc4\x9d','g')
    cadena = cadena.replace('\xc4\x9e','G')
    cadena = cadena.replace('\xc4\x9f','g')
    cadena = cadena.replace('\xc4\xa0','G')
    cadena = cadena.replace('\xc4\xa1','g')
    cadena = cadena.replace('\xc4\xa2','G')
    cadena = cadena.replace('\xc4\xa3','g')

    cadena = cadena.replace('\xc4\xa8','I')
    cadena = cadena.replace('\xc4\xa9','I')
    cadena = cadena.replace('\xc4\xaa','I')
    cadena = cadena.replace('\xc4\xab','I')
    cadena = cadena.replace('\xc4\xac','I')
    cadena = cadena.replace('\xc4\xad','I')
    cadena = cadena.replace('\xc4\xae','I')
    cadena = cadena.replace('\xc4\xaf','I')
    cadena = cadena.replace('\xc4\xb0','I')
    cadena = cadena.replace('\xc4\xb1','I')

    cadena = cadena.replace('\xc3\x8c','I')
    cadena = cadena.replace('\xc3\x8d','I')
    cadena = cadena.replace('\xc3\x8e','I')
    cadena = cadena.replace('\xc3\x8f','I')


    cadena = cadena.replace('\xc5\x8c','O')
    cadena = cadena.replace('\xc5\x8d','o')
    cadena = cadena.replace('\xc5\x8e','O')
    cadena = cadena.replace('\xc5\x8f','o')
    cadena = cadena.replace('\xc5\x90','O')
    cadena = cadena.replace('\xc5\x91','o')

    cadena = cadena.replace('\xc3\x92','O')
    cadena = cadena.replace('\xc3\x93','O')
    cadena = cadena.replace('\xc3\x94','O')
    cadena = cadena.replace('\xc3\x95','O')
    cadena = cadena.replace('\xc3\x96','O')

    cadena = cadena.replace('\xc5\xa8','U')
    cadena = cadena.replace('\xc5\xa9','u')
    cadena = cadena.replace('\xc5\xaa','U')
    cadena = cadena.replace('\xc5\xab','u')
    cadena = cadena.replace('\xc5\xac','U')
    cadena = cadena.replace('\xc5\xad','u')
    cadena = cadena.replace('\xc5\xae','U')
    cadena = cadena.replace('\xc5\xaf','u')
    cadena = cadena.replace('\xc5\xb0','U')
    cadena = cadena.replace('\xc5\xb1','u')
    cadena = cadena.replace('\xc5\xb2','U')
    cadena = cadena.replace('\xc5\xb3','u')

    cadena = cadena.replace('\xc3\x99','U')
    cadena = cadena.replace('\xc3\x9a','U')
    cadena = cadena.replace('\xc3\x9b','U')
    cadena = cadena.replace('\xc3\x9c','U')

    cadena = cadena.replace('&#8217;',"'")
    cadena = cadena.replace('&#8211;','y')

    

    return cadena


def get_dominio(url,lang):
    #import web_pdb;web_pdb.set_trace()
    o = urlparse.urlparse(url)
    dominio= o.netloc.upper()
    dominio=dominio.replace('WWW.','')
    if lang != None and lang != '':
        dominio=dominio + ' - ' + lang.upper()
    return dominio

def revisaInfobels(infolabels):
    newinfolabels={}
    for key in infolabels:
        valor = infolabels[key]
        if valor == None : continue
        if isinstance(valor, (list, dict, tuple)):
            if len(valor)>0:
                newinfolabels[key]=valor
        elif isinstance(valor, (str,unicode)):
            if valor != None and valor != '':
                newinfolabels[key]=valor
        else:
            newinfolabels[key]=valor
    return newinfolabels


def addItemMenu(label, thumbnail, url, IsPlayable = 'false', isFolder= True, infolabel = None, actores=None):

    handle = int(sys.argv[1])

    #logger.debug("addItemMenu - label:{0}, thumbnail: {1}, url: {2}, IsPlayable: {3}, isFolder: {4}".format(label,thumbnail,url,IsPlayable,isFolder))

    li= xbmcgui.ListItem(label=label, thumbnailImage=thumbnail)
    li.setProperty('IsPlayable', IsPlayable)

    #import web_pdb;web_pdb.set_trace()
    if infolabel != None and len(infolabel) >0 :
        newinfolabel=revisaInfobels(infolabel)
        if newinfolabel !=None:
            li.setInfo('video', newinfolabel)
            li.addContextMenuItems([('Datos Pelicula', 'XBMC.Action(Info)')])
    
    #actors = [{"name": "Actor 1", "role": "role 1"}, {"name": "Actor 2", "role": "role 2"}]
    #listitem.setCast(actors)
    #import web_pdb;web_pdb.set_trace()
    if actores != None and len(actores) >0 :
        li.setCast(actores)

    try:
        #listitem.setArt({ 'poster': 'poster.png', 'banner' : 'banner.png' })
        imagen=infolabel.get('thumbnail')
        art={'poster': thumbnail,'thumb': thumbnail,'banner': thumbnail,'fanart': thumbnail}
        li.setArt(art)

    except:
        print('no picturepath')

    

    xbmcplugin.addDirectoryItem(handle, listitem = li, url = url, isFolder = isFolder)


def giveColor(text, color, isBold=False):
    if isBold:
        text = '[B]%s[/B]' % text
    return '[COLOR %s]%s[/COLOR]' % (color, text)


def stripColor(text):
    text = re.sub(r'(\[.+?\])', '', text)
    return text

def giveColorItemSelecionadoLista(lista,posicion, color):
    item=lista[posicion]
    item= stripColor(item)
    item = giveColor(item,color,False)
    lista[posicion]=item
    return lista


def notify(header=None, msg='', icon_path=None, duration=2000, sound=None, ):
    # if header is None:
    #     header = get_name()
    # if sound is None:
    #     sound = get_setting('mute_notifications') == 'false'
    # if icon_path is None:
    #     icon_path = os.path.join(get_path(), 'icon.png')

    if sound is None:
        sound = False

    if icon_path is None:
        icon_path = xbmcgui.NOTIFICATION_INFO

    try:
        xbmcgui.Dialog().notification(header, msg, icon_path, duration, sound)
    except:
        builtin = "XBMC.Notification(%s,%s, %s, %s)" % (header, msg,icon_path, duration, sound)
        xbmc.executebuiltin(builtin)

def imdb_scraper(titulo,year=0):
    #import web_pdb;web_pdb.set_trace()
    imdbtitulo=titulo
    imdbtitulo=reemplazosEspeciales(titulo)
    imdb='https://api.themoviedb.org/3/search/movie?api_key=a1ab8b8669da03637a4b98fa39c39228&query='+ imdbtitulo +'&language=es'
    
    if year > 0:
        imdb='https://api.themoviedb.org/3/search/movie?api_key=a1ab8b8669da03637a4b98fa39c39228&query='+ imdbtitulo +'&language=es&year=' + str(year)

    imdb=imdb.replace(' ','+')
    plot=''
    respuesta= {}

    default_headers=default_headers_sin_ua
    default_headers['User-Agent']=getRandomUserAgent()

    req = urllib2.Request(imdb, None, default_headers)

    datosimdb = urllib2.urlopen(req).read()

    #lo elimino por arriba
    #datosimdb=requests.get(imdb).text
    imdbjson = json.loads(datosimdb)
    #plot=imdbjson.get('results')[2].get('title')
    
    actoresn={}
    if imdbjson.get('total_results')>0 :
        for item in imdbjson.get('results'):
            tituloimdb=unicodedata.normalize('NFKD', item.get('title')).encode('ascii', 'ignore').upper()
            try:
                titulopasado=unicodedata.normalize('NFKD', imdbtitulo).encode('ascii', 'ignore').upper()
            except:
                titulopasado=imdbtitulo.upper()
            
            tituloimdb_original= unicodedata.normalize('NFKD', item.get('original_title')).encode('ascii', 'ignore').upper()
            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                plot=item.get('overview')

                #si no se obtiene plot en español, lo traemos en ingles
                if plot=='' :
                    imdbingles=imdb.replace('language=es','language=en')
                    datosimdbingles=requests.get(imdbingles).text
                    imdbjsoningles = json.loads(datosimdbingles)
                    if imdbjsoningles.get('total_results')>0 :
                        for itemingles in imdbjsoningles.get('results'):
                            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                                plot=itemingles.get('overview')

                id=str(item.get('id'))
                originaltitle=item.get('original_title')
                votes=item.get('popularity')
                title = item.get('title')
                rating=item.get('vote_average')
                aired=item.get('release_date')
                poster_path = item.get('poster_path')
                if poster_path != None:
                    poster_path = 'https://image.tmdb.org/t/p/w300' + poster_path

                castandrole, actoresn =imdb_scraper_byid2(id)

                respuesta["plot"]=plot
                respuesta["id"]=id
                respuesta["votes"]=votes
                respuesta["title"]=title
                respuesta["rating"]=rating
                respuesta["aired"]=aired
                respuesta["poster_path"] = poster_path
                if castandrole != None or len(castandrole)> 0:
                    respuesta["castandrole"]= castandrole
                #respuesta["actores"] = actores




    return respuesta,actoresn

def imdb_scraper_byid2(id):
    url='https://api.themoviedb.org/3/movie/{movie_id}/credits?api_key=a1ab8b8669da03637a4b98fa39c39228&language=es-ES'
    urlpreparada=url.replace('{movie_id}',id)

    default_headers=default_headers_sin_ua
    default_headers['User-Agent']=getRandomUserAgent()
    req = urllib2.Request(urlpreparada, None, default_headers)
    datosimdb = urllib2.urlopen(req).read()

    #datosimdb = requests.get(urlpreparada).text
    imdbjson = json.loads(datosimdb)
    dic=[]
    dicsetcast=[]
    actores={}
    actoressetcast={}

    #actors = [{"name": "Actor 1", "role": "role 1"}, {"name": "Actor 2", "role": "role 2"}]
    for item in imdbjson.get('cast'):
        name=item.get('name')
        role=item.get('character')
        thumbnail=item.get('profile_path')
        if thumbnail != None:
            thumbnail = 'https://image.tmdb.org/t/p/w185/' + thumbnail
        order=item.get('cast_id')

        actores = [name, role]
        dic.append(actores)
        actoressetcast={'name':name,'role': role,'thumbnail':thumbnail,'order': order}
        dicsetcast.append(actoressetcast)

    return dic,dicsetcast

def play_video(url,handle):
    """
    Play a video by the provided path.
    :param path: str
    :return: None
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=url)
    try:
        # Pass the item to the Kodi player.
        xbmcplugin.setResolvedUrl(handle, True, listitem=play_item)
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok('Informacion', 'No Localizados enlaces')

def isDisableServidor(url):    
    try:
        dominio=get_dominio(url,'').lower()
    except:
        # dialog = xbmcgui.Dialog()
        # dialog.ok('fallo dominio', 'True')
        return True

    addon = xbmcaddon.Addon()
    estadoaddon = addon.getSetting(dominio)
    if not estadoaddon or 'false' in estadoaddon:
        estado=False
        # dialog = xbmcgui.Dialog()
        # dialog.ok(dominio, 'deshabilitado: false')
    else:
        estado= True
        # dialog = xbmcgui.Dialog()
        # dialog.ok( dominio, 'deshabilitado: true')
    if '/soon' in url:
        estado= True

    return estado

def getRandomUserAgent():
    user_agents = ["Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0",
                   "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0",
                   "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36",
                   "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9",
                   "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36",
                   "Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0",
                   "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
                   "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1)",
                   "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
                   "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0",
                   "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36",
                   "Opera/9.80 (Windows NT 6.2; Win64; x64) Presto/2.12.388 Version/12.17",
                   "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0",
                   "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0"]
    return user_agents[randint(0, len(user_agents) - 1)]

def getAddonData():
    dic={}
    addon         = xbmcaddon.Addon()
    addon_path    = addon.getAddonInfo('path')
    addonID       = addon.getAddonInfo('id')
    addonUserDataFolder = xbmc.translatePath("special://profile/addon_data/"+addonID)

    dic['addon'] = addon
    dic['addon_path'] = addon_path
    dic['addonID'] = addonID
    dic['addonUserDataFolder'] = addonUserDataFolder
    return dic

def getAddonUserDataFolder():
    addon         = xbmcaddon.Addon()
    addonID       = addon.getAddonInfo('id')
    addonUserDataFolder = xbmc.translatePath("special://profile/addon_data/"+addonID)
    return addonUserDataFolder

def remove_dir(path):
       dirList, flsList = xbmcvfs.listdir(path)
       for fl in flsList:
            if fl.endswith('.pcl') :
                xbmcvfs.delete(os.path.join(path, fl))

def getcachesetting():
    addon = xbmcaddon.Addon()
    settingcache = addon.getSetting('cache')
    if settingcache == 'true':
        if getrestaurarcache():
            addon.setSetting('cache','false')
        return True
    else:
        return False

def getrestaurarcache():
    addon = xbmcaddon.Addon()
    settingrestaurarcache = addon.getSetting('restaurarcache')
    if settingrestaurarcache == 'true':
        return True
    else:
        return False














