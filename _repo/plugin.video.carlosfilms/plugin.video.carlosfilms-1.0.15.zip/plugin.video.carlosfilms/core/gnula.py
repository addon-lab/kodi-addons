# -*- coding: utf-8 -*-
import requests
#from bs4 import BeautifulSoup
import jsbeautifier
import re
import json
from core import logger
from core import tools
from core import httptools
from core import tmdb
import resolveurl

# para nuevos plugins
from plugins import evoloadio
from plugins import gamovideo
from plugins import videossh
from plugins.resolver import Switcher


import xbmcaddon
import xbmc
#import unicodedata
#import urlresolver
#import urllib2

from simpleplugin import Plugin
plugin = Plugin()
#with plugin.get_storage() as storage:  # Create a storage object
    #storage['estrenos'] = ""  # Store data
    #value2 = storage['key2']  # Retrieve data


host = "https://www.gnula.nu/"
host_search = "https://cse.google.com/cse/element/v1?rsz=filtered_cse&num=20&hl=es&source=gcsc&gss=.es&sig=c891f6315aacc94dc79953d1f142739e&cx=014793692610101313036:vwtjajbclpq&q=%s&safe=off&cse_tok=%s&googlehost=www.google.com&callback=google.search.Search.csqr6098&nocache=1540313852177&start=0"
item_per_page = 20

IDIOMAS = {'VC':'Esp', 'VL':'Lat', 'VS':'VOSE', 'castellano':'Esp', 'latino':'Lat', 'vose':'VOSE'}


def get_datospartida():
    listdic=[]
    #import web_pdb;web_pdb.set_trace()
    # __addon__       = xbmcaddon.Addon(id='plugin.video.carlosfilms')
    # __addondir__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ) 

    # path = __addon__.getAddonInfo('path').decode('utf-8')

    imagenestrenos = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/estrenos.png").decode('utf-8')
    imagenrecomendadas = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/recomendadas.jpg").decode('utf-8')
    imagengeneros = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/generos.png").decode('utf-8')
    imagenbuscar = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/buscar.png").decode('utf-8')
    
    #/Users/carlosrentero/Library/Application Support/Kodi/addons/plugin.video.carlosfilms
    #/Users/carlosrentero/Library/Application Support/Kodi/userdata/resources/media/estrenos.png'
    # media= os.path.join(path, 'media')
    # imagenestrenos='estrenos.png'
    # imagenlocal=os.path.join(media, filename.decode('utf-8'))

    opcion1={'urlvalue':host + 'peliculas-online/lista-de-peliculas-online-parte-1/',
          'imagen':imagenestrenos,
          'nombre':'Estrenos','accion':'peliculas'}

    opcion2={'urlvalue':host + 'peliculas-online/lista-de-peliculas-recomendadas/',
          'imagen':imagenrecomendadas,
          'nombre':'Recomendadas','accion':'peliculas'}

    opcion3={'urlvalue':host + 'generos/lista-de-generos/',
          'imagen':imagengeneros,
          'nombre':'Generos','accion':'generos'}

    opcion4={'urlvalue': host_search,
          'imagen':imagenbuscar,
          'nombre':'Buscar','accion':'searcher'}

    listdic.append(opcion1)
    listdic.append(opcion2)
    listdic.append(opcion3)
    listdic.append(opcion4)

    return listdic

@plugin.cached(230)
def get_peliculas(url_,posicion=0):
    #import web_pdb;web_pdb.set_trace()

    next = True
    itemlistInicial = []
    itemlist = []
    
    text=httptools.get_httpdocument(url_)
    regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    encuentros = re.findall( regex, text , re.DOTALL)            #[0:3]

    first = int(posicion)
    last = first + 10

    if last > len(encuentros):
        last = len(encuentros)
        next = False
 

    regex = r"href=\"(.*?)\">(.*?)<.*?src=\"(.*?)\".*?\[(.*?)\]\s*\[.*?\">([A-Z\-].*?)<.*?strong>(.*?)$"
    regexUrl = r"href=\"(.*?)\""
    regexTitulo = r"href=\".*?\">(.*?)<"
    regexImagen = r"src=\"(.*?)\""
    regexIdioma = r"\[(.*?)](?:\s|\[)"
    regexCalidad = r"\">([A-Z\\-]+)<"
    regexGeneros = r"<strong>(.*?)$"
    regexYear = r"-(\d{4})-"
    
    for pelis in encuentros[first:last]:
        item = {}
        try:
            item['url'] = re.findall( regexUrl , pelis , re.MULTILINE)[0]
            item['year'] = re.findall(regexYear, item['url'], re.MULTILINE)[0]
            item['title'] = tools.reemplazos_especiales(re.findall( regexTitulo , pelis , re.MULTILINE)[0])
            item['image'] = re.findall( regexImagen, pelis, re.MULTILINE)[0]
            item['calidad'] = re.findall(regexCalidad, pelis, re.MULTILINE)[0]
            item['genre'] = re.findall(regexGeneros, pelis, re.MULTILINE)[0]
            languages = re.findall(regexIdioma,pelis, re.MULTILINE)[0]
            item['languages'] = get_languages(languages)
            itemlistInicial.append(item)
        except:
            print('error pelis')

    if len(itemlistInicial)>0:
        #import web_pdb;web_pdb.set_trace()
        datos_completos = tmdb.get_tmdb(itemlistInicial)
        #import web_pdb;web_pdb.set_trace()
        for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url = itemlist_['url']
            titulo_gnula = itemlist_['title']
            image_gnula = itemlist_['image']
            calidad = itemlist_['calidad']
            generos = itemlist_['genre']
            languages = itemlist_['languages']
            year = itemlist_['year']

            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [title, str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': generos,
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)


    url_next_page = url_
    first = last

    if next:
        objeto = {'accion' : 'peliculas',
                'contentTitle' : 'Siguiente >>',
                'year' : '',
                'language':'',
                'plot' : '',
                'quality':'',
                'title' : 'Siguiente >>',
                'thumbnail' :'',
                'url' : url_next_page,
                'posicion': first}

    itemlist.append(objeto)

    return itemlist

    # with plugin.get_storage() as storage:
    #     try:
    #         encuentrosestrenos = storage['estrenos']
    #     except:
    #         encuentrosestrenos = None


    # if (encuentrosestrenos == None):
    #     text=httptools.get_httpdocument(url_)
    #     regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    #     encuentros = re.findall( regex, text , re.DOTALL)            #[0:3]
    #     with plugin.get_storage() as storage:
    #         try:
    #             storage['estrenos']= encuentros
    #         except:
    #             encuentrosestrenos = None
        
    # else:
        
    #         encuentros=encuentrosestrenos




@plugin.cached(230)
def get_generos(url):
    itemlist = []
    data = httptools.get_httpdocument(url)

    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)" title="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)
    for titulo, url, plot in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url,
                  'plot':plot
                  }
        itemlist.append(objeto)

    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)
    for titulo, url in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url
                  }
        if url in [it.get('url') for it in itemlist]: continue  # descartar repetidos
        itemlist.append(objeto)

    return sorted(itemlist, key=lambda it: it.get('title'))

@plugin.cached(230)
def list_peliculas_generos(url_,posicion=0):
    IDIOMAS = {'VC': 'Esp', 'VL': 'Lat', 'VS': 'VOSE', 'castellano': 'Esp', 'latino': 'Lat', 'vose': 'VOSE'}
    itemlist = []
    next = True

    data = text=httptools.get_httpdocument(url_)

    patron = '<a class="Ntooltip" href="([^"]+)">([^<]+)<span><br[^<]+'
    patron += '<img src="([^"]+)"></span></a>(.*?)<br'
    matches = re.compile(patron, re.DOTALL).findall(data)

    first = int(posicion)
    last = first + 10

    if last > len(matches):
        last = len(matches)
        next = False

    
    itemlistInicial = []
    
    for urlscraped, title, thumb, resto in matches[first:last]:
        datosscrapped={}
        # title=unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').upper()
        patron = '-(\d+)-online/$'
        try:
            year = re.compile(patron, re.DOTALL).findall(urlscraped)[0]
        except:
            year = 0
        patron ='<span style="[^"]+">([^<]+)</span>'
        spans = re.compile(patron, re.DOTALL).findall(resto)
        #year = scrapertools.find_single_match(url, '-(\d+)-online/$')
        #spans = scrapertools.find_multiple_matches(resto, '<span style="[^"]+">([^<]+)</span>')
        langs = []
        quality = ''
        for span in spans:
            if span.startswith('(') and span.endswith(')'):
                lg = span[1:-1]
                langs.append(IDIOMAS.get(lg, lg))
            elif len(langs) > 0:
                quality = span
                break
        if langs != None and len(langs)>0:
            lenguages = ','.join(langs)
        else:
            lenguages=''

        title=tools.reemplazos_especiales(title)

        if year > 0:
            title=tools.quitanumerosfinales(title)

        datosscrapped['title'] = tools.reemplazos_especiales(title)
        datosscrapped['url'] = urlscraped
        datosscrapped['year'] = year
        datosscrapped['calidad'] = quality

        datosscrapped['languages'] = lenguages
        #datosscrapped['languages'] = langs
        datosscrapped['image'] = thumb

        itemlistInicial.append(datosscrapped)


    #import web_pdb;web_pdb.set_trace()
    datos_completos = tmdb.get_tmdb(itemlistInicial)   
    #infolabels,actores = tools.imdb_scraper(title,year)
    ####
    for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url = itemlist_['url']
            titulo_gnula = itemlist_['title']
            image_gnula = itemlist_['image']
            calidad = itemlist_['calidad']
            #generos = itemlist_['genre']
            languages = itemlist_['languages']
            year = itemlist_['year']

            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [title, str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'languages': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': 'generos',
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)

    url_next_page = url_
    first = last

    if next:
        objeto = {'accion': 'peliculas_generos',
                    'url': url_next_page,
                    'title': 'Siguiente >>',
                    'thumbnail': '',
                    'languages': '',
                    'qualities': '',
                    'year': '',
                    'posicion': first}

        itemlist.append(objeto)

    
    return itemlist

#@plugin.cached(230)
def findvideos(url_):
    #import web_pdb;web_pdb.set_trace()
    itemlist = []
    data = httptools.get_httpdocument(url_)

    patron = r"<em>(.*?)<\/div><p>"
    bloques_contenedores=tools.find_multiple_matches(data, 'contenedor_tab.*?/table') #revisar
    if bloques_contenedores!=None:
        patron_idioma=r"em>opci.*?,\s*(.*?),"
        lang=tools.find_multiple_matches(data, patron_idioma)
        if lang==None or len(lang)<1:
            patron_idioma = r">Ver pel.*?\[.*?,\s*(.*?),"
            lang=tools.find_multiple_matches(data, patron_idioma)
        bloque=0
        for block in bloques_contenedores:
            patron_videos=r"(?:src|href)=\"(http.*?)\""
            #import web_pdb;web_pdb.set_trace()
            urls_videos=tools.find_multiple_matches(block,patron_videos)
            for url in urls_videos:
                if tools.isDisableServidor(url):continue
                objeto = {'accion' : 'play',
                    'url' : url,
                    'lang' : lang[bloque]
                    }
                itemlist.append(objeto)
            bloque=bloque+1
    else:
        itemlist=findvideos(url)

    return itemlist


class Item:
  def __init__(self, url, age):
    self.url = url
    self.age = age

  def myfunc(self):
    print("Hello my name is " + self.url)



#@plugin.cached(2)
def search_alfa(texto):
    item = Item
    texto = texto.replace(" ", "+")
    data = httptools.get_httpdocument(host)
    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')
    data = httptools.get_httpdocument("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv)
    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:                                       #Evita un loop si error
        item.url = host_search %(texto, cse_token)
        try:
            return sub_search_alfa(item)
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        except:
            import sys
            for line in sys.exc_info():
                print("%s" % line)
    return []


def sub_search_alfa(item):
    #import web_pdb;web_pdb.set_trace()
    itemlistinicial = []
    itemlist = []
    item_per_page = 50
    while True:
        req=httptools.get_request(item.url)
        if req.status_code != 200:
            return

        data = req.text
        
        if len(data) < 500 :      #Evita un loop si error
            break

        #import web_pdb;web_pdb.set_trace()
        page = int(tools.find_single_match(item.url, ".*?start=(\d+)")) + item_per_page
        item.url = tools.find_single_match(item.url, "(.*?start=)") + str(page)
        patron =  '(?s)clicktrackUrl":\s*".*?q=(.*?)".*?'
        patron += 'titleNoFormatting":\s*"([^"]+)".*?'
        patron += 'cseThumbnail.*?"src":\s*"([^"]+)"' # se usa el thumb de google

        matches = tools.find_multiple_matches(data, patron)
        for scrapedurl, scrapedtitle, scrapedthumbnail in matches:
            scrapedurl = tools.find_single_match(scrapedurl, ".*?online/")
            scrapedtitle = scrapedtitle.replace(" online", "").replace("<b>", "").replace("</b>", "")
            if "ver-" not in scrapedurl:
                continue
            year = tools.find_single_match(scrapedtitle, "\d{4}")
            contentTitle = scrapedtitle.replace(tools.find_single_match('\[.+', scrapedtitle),"")
            contentTitle = scrapedtitle.replace("(%s)" %year,"").replace("Ver","").strip()
            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'language',
                    'plot' : 'plot',
                    'quality':'quality',
                    'title' : contentTitle,           #scrapedtitle,
                    'thumbnail' :scrapedthumbnail,
                    'url' : scrapedurl,
                    'genre': 'genre'
                    }
            itemlistinicial.append(objeto)
    
    if len(itemlistinicial) > 0:
        #import web_pdb;web_pdb.set_trace()
        datos_completos=tmdb.get_tmdb(itemlistinicial)
        for item in datos_completos:
            itemlist_ = item['itemlist']
            infolabels = item['infolabels']
            actores = item['actores']

            url_gnula = itemlist_['url']
            titulo_gnula = itemlist_['title']
            year = itemlist_['year']
            thumbnail_gnula = itemlist_['thumbnail']


            tituloespanol = infolabels.get('title')
            poster_path = infolabels.get('poster_path')
            plot = infolabels.get('plot')

            puntuacion = infolabels.get('rating')

            if tituloespanol:
                titulo = tituloespanol
            else:
                titulo = titulo_gnula

            if poster_path:
                thumbnail = poster_path
            else:
                thumbnail = thumbnail_gnula

            if puntuacion > 0:
                contentTitle = (titulo + ' - ' + str(year) + ' (' + str(puntuacion) + ')').replace("'", "")
            else:
                contentTitle = (titulo + ' - ' + str(year)).replace("'", "")

            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'',
                    'plot' : plot,
                    'quality':'',
                    'title' : titulo,           #scrapedtitle,
                    'thumbnail' :thumbnail,
                    'url' : url_gnula,
                    'genre': '',
                    'infolabels': infolabels,
                    'actores': actores
                    }
            itemlist.append(objeto)

    return itemlist

    

def get_link(urldada):
        #import web_pdb;web_pdb.set_trace()
        hmf = resolveurl.HostedMediaFile(url=urldada)
        if not hmf:
            motivo = 'Servidor aun no soportado:[CR]%s' % tools.get_dominio(url=urldada,lang='')
            motivoresolveUrl=motivo
            #tools.notify('Link no soportado: %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
            resolved=False
        else:
            try:
                resolved = resolveurl.resolve(urldada)
                motivo = ''
                #resolved2 = urlresolver.resolve(urldada)
            except:
                motivo = 'Pelicula borrada del servidor:[CR]%s' % tools.get_dominio(url=urldada,lang='')
                motivoresolveUrl=motivo
                #tools.notify('Pelicula borrada del servidor : %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
                xbmc.log("ERROR RESOLVER ADDON: " + urldada)
                resolved = False

        if resolved == False:
            resolved = Switcher(urldada).get_server()
            if 'http' not in resolved:
                motivo =  motivoresolveUrl
                resolved = False
        
        if resolved == False:
            tools.notify(motivo,duration=200)
        return resolved


def get_languages(valores):
    regex = r"\((V[A-Z].*?)\)"
    language = []
    result = ''
    languages = re.findall(regex, valores, re.DOTALL)
    if len(languages)>0:
        for lang in languages:
            langu = IDIOMAS.get(lang, lang)
            language.append(langu)
        language = sorted(language)
        result=','.join(language)
    return result



