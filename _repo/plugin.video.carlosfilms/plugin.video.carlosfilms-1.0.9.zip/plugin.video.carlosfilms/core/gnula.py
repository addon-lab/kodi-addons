# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import jsbeautifier
import re
import json
from core import logger
from core import tools
from core import httptools
from core import tmdb
import resolveurl
import xbmcaddon
import xbmc
import unicodedata
import urlresolver
import urllib2

host = "https://www.gnula.nu/"
host_search = "https://cse.google.com/cse/element/v1?rsz=filtered_cse&num=20&hl=es&source=gcsc&gss=.es&sig=c891f6315aacc94dc79953d1f142739e&cx=014793692610101313036:vwtjajbclpq&q=%s&safe=off&cse_tok=%s&googlehost=www.google.com&callback=google.search.Search.csqr6098&nocache=1540313852177&start=0"
item_per_page = 20

IDIOMAS = {'VC':'Esp', 'VL':'Lat', 'VS':'VOSE', 'castellano':'Esp', 'latino':'Lat', 'vose':'VOSE'}

# Headers por defecto, si no se especifica nada
default_headers_sin_ua = dict()
default_headers_sin_ua["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
default_headers_sin_ua["Accept-Language"] = "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3"
default_headers_sin_ua["Accept-Charset"] = "UTF-8"
default_headers_sin_ua["Accept-Encoding"] = "inflate"

def get_datospartida():
    listdic=[]
    #import web_pdb;web_pdb.set_trace()
    # __addon__       = xbmcaddon.Addon(id='plugin.video.carlosfilms')
    # __addondir__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ) 

    # path = __addon__.getAddonInfo('path').decode('utf-8')

    imagenestrenos = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/estrenos.png").decode('utf-8')
    imagenrecomendadas = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/recomendadas.jpg").decode('utf-8')
    imagengeneros = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/generos.jpg").decode('utf-8')
    imagenbuscar = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/buscar.jpg").decode('utf-8')
    
    #/Users/carlosrentero/Library/Application Support/Kodi/addons/plugin.video.carlosfilms
    #/Users/carlosrentero/Library/Application Support/Kodi/userdata/resources/media/estrenos.png'
    # media= os.path.join(path, 'media')
    # imagenestrenos='estrenos.png'
    # imagenlocal=os.path.join(media, filename.decode('utf-8'))

    opcion1={'urlvalue':host + 'peliculas-online/lista-de-peliculas-online-parte-1/',
          'imagen':imagenestrenos,
          'nombre':'Estrenos','accion':'peliculas'}

    opcion2={'urlvalue':host + 'peliculas-online/lista-de-peliculas-recomendadas/',
          'imagen':imagenrecomendadas,
          'nombre':'Recomendadas','accion':'peliculas'}

    opcion3={'urlvalue':host + 'generos/lista-de-generos/',
          'imagen':imagengeneros,
          'nombre':'Generos','accion':'generos'}

    opcion4={'urlvalue': host_search,
          'imagen':imagenbuscar,
          'nombre':'Buscar','accion':'searcher'}

    listdic.append(opcion1)
    listdic.append(opcion2)
    listdic.append(opcion3)
    listdic.append(opcion4)

    return listdic

def get_peliculas(url_,posicion=0):
    next = True
    itemlistInicial = []
    itemlist = []
    text=httptools.get_link(url_)
    regex = r"<a class=\"Ntooltip\"\s*(.*?)<\/strong"
    encuentros = re.findall( regex, text , re.DOTALL)            #[0:3]

    first = int(posicion)
    last = first + 20

    if last > len(encuentros):
        last = len(encuentros)
        next = False
 

    regex = r"href=\"(.*?)\">(.*?)<.*?src=\"(.*?)\".*?\[(.*?)\]\s*\[.*?\">([A-Z\-].*?)<.*?strong>(.*?)$"
    regexUrl = r"href=\"(.*?)\""
    regexTitulo = r"href=\".*?\">(.*?)<"
    regexImagen = r"src=\"(.*?)\""
    regexIdioma = r"\[(.*?)](?:\s|\[)"
    regexCalidad = r"\">([A-Z\\-]+)<"
    regexGeneros = r"<strong>(.*?)$"
    regexYear = r"-(\d{4})-"
    
    for pelis in encuentros[first:last]:
        item = {}
        try:
            item['url'] = re.findall( regexUrl , pelis , re.MULTILINE)[0]
            item['year'] = re.findall(regexYear, item['url'], re.MULTILINE)[0]
            item['title'] = tools.reemplazos_especiales(re.findall( regexTitulo , pelis , re.MULTILINE)[0])
            item['image'] = re.findall( regexImagen, pelis, re.MULTILINE)[0]
            item['calidad'] = re.findall(regexCalidad, pelis, re.MULTILINE)[0]
            item['genre'] = re.findall(regexGeneros, pelis, re.MULTILINE)[0]
            languages = re.findall(regexIdioma,pelis, re.MULTILINE)[0]
            item['languages'] = get_languages(languages)
            itemlistInicial.append(item)
        except:
            print('error pelis')

    if len(itemlistInicial)>0:
        for item in itemlistInicial:
            url = item['url']
            titulo_gnula = item['title']
            image_gnula = item['image']
            calidad = item['calidad']
            generos = item['genre']
            languages = item['languages']
            year = item['year']
            infolabels, actores = tmdb.imdb_scraper(item.get('title'), item.get('year'))
            if len(infolabels) > 0:
                plot = infolabels["plot"]
                titulo_espanol=infolabels["title"]
                image_imdb= infolabels["poster_path"]
                if titulo_espanol:
                    title = titulo_espanol
                else:
                    title = titulo_gnula
                if image_imdb:
                    image = image_imdb
                else:
                    image =image_gnula
            else:
                title=titulo_gnula
                image=image_gnula
                plot=''

            separator = ' - '
            contentlist = [title, str(year), languages, calidad]
            contentTitle = separator.join(contentlist)

            objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': languages,
                      'plot': plot,
                      'quality': calidad,
                      'title': title,
                      'thumbnail': image,
                      'url': url,
                      'genre': generos,
                      'infolabels': infolabels,
                      'actores': actores}
            itemlist.append(objeto)

    url_next_page = url_
    first = last

    if next:
        objeto = {'accion' : 'peliculas',
                'contentTitle' : 'Siguiente >>',
                'year' : '',
                'language':'',
                'plot' : '',
                'quality':'',
                'title' : 'Siguiente >>',
                'thumbnail' :'',
                'url' : url_next_page,
                'posicion': first}

    itemlist.append(objeto)


    #     itemlist.append(item.clone(title="Siguiente >>", url=url_next_page, action='peliculas', first=first))

    return itemlist

def get_generos(url):
    itemlist = []

    # req = requests.get(url)
    # # import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return

    # data = req.text
    default_headers=default_headers_sin_ua
    default_headers['User-Agent']=tools.getRandomUserAgent()
    req = urllib2.Request(url, None, default_headers)
    data = urllib2.urlopen(req).read()

    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)" title="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)
    for titulo, url, plot in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url,
                  'plot':plot
                  }
        itemlist.append(objeto)

    patron = '<td>\s*<strong>([^<]+)</strong>\s*\[<a href="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)
    for titulo, url in matches:
        objeto = {'accion': 'peliculas_generos',
                  'title': titulo,
                  'url': url
                  }
        if url in [it.get('url') for it in itemlist]: continue  # descartar repetidos
        itemlist.append(objeto)

    return sorted(itemlist, key=lambda it: it.get('title'))

def list_peliculas_generos(url,posicion=0):
    IDIOMAS = {'VC': 'Esp', 'VL': 'Lat', 'VS': 'VOSE', 'castellano': 'Esp', 'latino': 'Lat', 'vose': 'VOSE'}
    itemlist = []
    next = True


    # req = requests.get(url)
    # # import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return

    # data = req.text

    default_headers=default_headers_sin_ua
    default_headers['User-Agent']=tools.getRandomUserAgent()
    req = urllib2.Request(url, None, default_headers)
    data = urllib2.urlopen(req).read()

    patron = '<a class="Ntooltip" href="([^"]+)">([^<]+)<span><br[^<]+'
    patron += '<img src="([^"]+)"></span></a>(.*?)<br'
    matches = re.compile(patron, re.DOTALL).findall(data)

    first = int(posicion)
    last = first + 10

    if last > len(matches):
        last = len(matches)
        next = False

    # if item.filtro_lang:  # reducir lista según idioma
    #     matches = filter(lambda m: '(%s)' % item.filtro_lang in m[3], matches)
    #
    # if item.filtro_search:  # reducir lista según texto buscado
    #     buscado = item.filtro_search.lower().strip()
    #     if ' ' not in buscado:
    #         matches = filter(lambda m: buscado in m[1].lower(), matches)
    #     else:
    #         palabras = filter(lambda p: len(p) > 3,
    #                           buscado.split(' '))  # descartar palabras demasiado cortas (la de los etc)
    #         if len(palabras) == 0: return []  # No hay palabras a buscar
    #
    #         def contiene(texto, palabras):
    #             found = False
    #             for palabra in palabras:
    #                 if palabra in texto: found = True; break
    #             return found
    #
    #         matches = filter(lambda m: contiene(m[1].lower(), palabras), matches)

    for urlscraped, title, thumb, resto in matches[first:last]:
        # title=unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').upper()
        patron = '-(\d+)-online/$'
        try:
            year = re.compile(patron, re.DOTALL).findall(url)[0]
        except:
            year = 0
        patron ='<span style="[^"]+">([^<]+)</span>'
        spans = re.compile(patron, re.DOTALL).findall(resto)
        #year = scrapertools.find_single_match(url, '-(\d+)-online/$')
        #spans = scrapertools.find_multiple_matches(resto, '<span style="[^"]+">([^<]+)</span>')
        langs = []
        quality = ''
        for span in spans:
            if span.startswith('(') and span.endswith(')'):
                lg = span[1:-1]
                langs.append(IDIOMAS.get(lg, lg))
            elif len(langs) > 0:
                quality = span
                break
        
        infolabels,actores = tools.imdb_scraper(title,year)
        tituloespanol=infolabels.get('title')
        poster_path=infolabels.get('poster_path')

        if tituloespanol!= None:
            title=tituloespanol

        if poster_path!= None:
            thumb=poster_path


        objecto={ 'accion':'findvideos',
                  'url':urlscraped,
                  'title':title,
                  'thumbnail':thumb,
                  'languages':', '.join(langs),
                  'qualities':quality,
                  'year': year,
                  'infolabels': infolabels,
                  'actores': actores
        }

        itemlist.append(objecto)

    url_next_page = url
    first = last

    if next:
        objeto = {'accion': 'peliculas_generos',
                    'url': url_next_page,
                    'title': 'Siguiente >>',
                    'thumbnail': '',
                    'languages': '',
                    'qualities': '',
                    'year': '',
                    'posicion': first}

        itemlist.append(objeto)

    
    return itemlist

def findvideos(url_):
    
    itemlist = []
    #req=requests.get(url_)
    # #import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return
    
    # data=req.text
    import web_pdb;web_pdb.set_trace()
    default_headers=default_headers_sin_ua
    default_headers['User-Agent']=tools.getRandomUserAgent()
    req = urllib2.Request(url_, None, default_headers)
    data = urllib2.urlopen(req).read()

    patron = '<strong>Ver película online.*?>.*?>([^<]+)'
    scrapedopcion = tools.find_single_match(data, patron)
    titulo_opcional = tools.find_single_match(scrapedopcion, ".*?, (.*)").upper()
    bloque  = tools.find_multiple_matches(data, 'contenedor_tab.*?/table')
    cuenta = 0
    for datos in bloque:
        cuenta = cuenta + 1
        patron = '<em>((?:opciÃ³n|opción) %s.*?)</em>' %cuenta
        scrapedopcion = tools.find_single_match(data, patron)
        titulo_opcion = "(" + tools.find_single_match(scrapedopcion, "op.*?, (.*)").upper() + ")"
        if "TRAILER" in titulo_opcion or titulo_opcion == "()":
            titulo_opcion = "(" + titulo_opcional + ")"
        urls = tools.find_multiple_matches(datos, '(?:src|href)="([^"]+)')
        titulo = "Ver en %s " + titulo_opcion
        for url in urls:
            if tools.isDisableServidor(url):continue
            objeto = {'accion' : 'play',
                'lang' : 'lang',
                'url' : url
                }

            itemlist.append(objeto)
            
    
    #tmdb.set_infoLabels_itemlist(itemlist, True)

    return itemlist

def findvideos2(url_):
    #import web_pdb;web_pdb.set_trace()
    itemlist = []
    default_headers=default_headers_sin_ua
    default_headers['User-Agent']=tools.getRandomUserAgent()
    req = urllib2.Request(url_, None, default_headers)
    data = urllib2.urlopen(req).read()

    #+++++++++++++++++++++++++++++++++++++++++
    # req=requests.get(url_)
    # #import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return
    
    # data=req.text
    #import web_pdb;web_pdb.set_trace()

    patron = r"<em>(.*?)<\/div><p>"
    bloques_contenedores=tools.find_multiple_matches(data, 'contenedor_tab.*?/table') #revisar
    if bloques_contenedores!=None:
        patron_idioma=r"em>opci.*?,\s*(.*?),"
        lang=tools.find_multiple_matches(data, patron_idioma)
        if lang==None or len(lang)<1:
            patron_idioma = r">Ver pel.*?\[.*?,\s*(.*?),"
            lang=tools.find_multiple_matches(data, patron_idioma)
        bloque=0
        for block in bloques_contenedores:
            patron_videos=r"(?:src|href)=\"(http.*?)\""
            #import web_pdb;web_pdb.set_trace()
            urls_videos=tools.find_multiple_matches(block,patron_videos)
            for url in urls_videos:
                if tools.isDisableServidor(url):continue
                objeto = {'accion' : 'play',
                    'url' : url,
                    'lang' : lang[bloque]
                    }
                itemlist.append(objeto)
            bloque=bloque+1
    else:
        itemlist=findvideos(url)

    return itemlist


def getLinksLatinoWebTV2():
    res=[]
    resLink=[]
    resImg=[]
    dict={}
    url="https://www.latino-web-tv.com"
    req=requests.get(url)
    soup=BeautifulSoup(req.content, 'html.parser')
    job_elems =  soup.find_all('div', class_='elementor-image')
    for links in job_elems:
        resultLinks=links.find_all('a')
        resultImg = links.find_all('img')
        resultUrl = resultLinks[0].get('href')
        image = resultImg[0].get('src')
        regex = r"www\.latino-web-tv\.com\/(.*?)\/"
        nombre=tools.findall(regex,resultUrl,re.MULTILINE)[0]
        nombre=nombre.replace('-',' ').replace(' en vivo','')
        nombre=nombre.upper()

        dict={'url':resultUrl,'imagen':image,'nombre':nombre}
        res.append(dict)
    return res

def getPassphrase_CadenaEncriptadaB64(url):
        s = requests.Session()
        req = s.get(url)
        # cookies=req.cookies
        # regex = r"(eval.*?\}\)\))"
        regex = r"src=\"(.*?embed\.latino.*?)(?:\s|\")"
        new_url = tools.findall(regex, req.text, re.MULTILINE)[0]
        req = s.get(new_url)
        regex = r"(eval.*?\}\)\))"
        packed = tools.findall(regex, req.text, re.MULTILINE)[0]
        encrypted = packed

        # encrypted = r'''eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('6 u(){d b=/1L/i.14(s.15)||(6(c){8 c.16()==="[17 18]"})(!s.m||(19 m!=="1a"&&m.1b));g(b){8 f}g(s.13&&D()>=x){8 f}d n=r.q.t(/1c\\/([0-9]{2,})/i);g(n&&B(n[1])>=x){8 f}d a=(r.q.t(/1e|1f\\//)?f:l);g(a){8 f}8 l}6 D(){d b=r.q.t(/1g(e|1h)\\/([0-9]+)\\./);8 b?B(b[2],10):l};d k;d o;$.1i({1j:"/j.1k",1l:"1m",j:{1d:"0"},12:6(j,V,Z){7=O N.M({P:U.W(j["S"]),Y:"#7",X:"T",R:[Q],1n:u(),1p:!1,1K:{22:"#F",20:"#F"},1Y:"G%",1N:"G%",1S:{"1Q":{"w":"1o - y-C-A.z",},"1W":{"w":"1M 1O - y-C-A.z",},},1P:{1R:6(e){v()}},1T:{1U:\'1V\',1X:{5:\'1Z\',4:\'21\',3:\'1A\',2:\'1r\',1:\'1s\',0:\'1t\',}}});H(6(){7.p();1u.1v("p!")},1w)},});6 v(){$(".J-K").L("E","1x");k=10;o=1y(6(){1q.1z("1B").1C=10- --k;g(k<=0)1D(o)},1E);H(6(){I()},1F)}6 I(){$(".J-K").L("E","1G");d h=7.1H(7);h=O N.M(h.1I);7.1J();7=h;7.p();7.11()}',62,127,'||||||function|player|return|||||var||true|if|newplayer||data|timeleft|false|safari|ff|downloadTimer|play|userAgent|navigator|window|match|startMuted|errorPlaying|live|66|Latino|com|TV|parseInt|Web|getChromeVersion|display|00FD2A|100|setTimeout|relOadPlayer|stream|offline|css|Player|Clappr|new|source|LevelSelector|plugins|streamdata|auto|MARIOCSCRYPT|textStatus|load_data|preload|parentId|jqXHR||unmute|success|chrome|test|HTMLElement|toString|object|SafariRemoteNotification|typeof|undefined|pushNotification|firefox|id|Opera|OPR|Chrom|ium|ajax|url|json|type|POST|mute|LIVE|autoPlay|document|360p|240p|144p|console|log|500|table|setInterval|getElementById|480p|progressBar|value|clearInterval|1000|10000|none|configure|options|destroy|mediacontrol|constructor|EN|height|VIVO|events|en|onError|strings|levelSelectorConfig|title|Quality|es|labels|width|1080p|buttons|720p|seekbar'.split('|'),0,{}))'''
        unpacked = jsbeautifier.beautify(encrypted)
        print(unpacked)
        # de aqui nos vale el id y la direccion del json
        regexid = r"id:\s*\"(\d*)\""
        id = tools.findall(regexid, unpacked, re.MULTILINE)[0]
        regexJson = r"url:\s*\"(.*?)\""
        argumento = tools.findall(regexJson, unpacked, re.MULTILINE)[0]
        urlJson = "https://embed.latino-web-tv.com" + argumento
        # de este me vale el pass
        js = "https://embed.latino-web-tv.com/config-player.js"
        req = s.get(js)
        unpacked = jsbeautifier.beautify(req.text)
        regexpassword = r"openSSLKey.*?\"(.*?)\""


        passwordAes = tools.findall(regexpassword, unpacked, re.MULTILINE)[0]

        # ahora obtenemos los datos encryptados
        postdata = {'id': id}
        req = s.post(urlJson, data=postdata, headers={'referer': 'https://embed.latino-web-tv.com/tnt',
                                                      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 OPR/72.0.3815.400',
                                                      'Origin': 'https://embed.latino-web-tv.com'})
        json_data = json.loads(req.text)
        #import web_pdb;web_pdb.set_trace()
        cadenaEncryptada = json_data['streamdata']

        return passwordAes, cadenaEncryptada

# notify(header=None, msg='', duration=2000, sound=None, icon_path=None):


# def get_link(urldada):
#         import web_pdb;web_pdb.set_trace()
#         hmf = resolveurl.HostedMediaFile(url=urldada)
#         if not hmf:
#             tools.notify('Link no soportado: %s' % (urldada), duration=17500)
#         try:
#             resolved = resolveurl.resolve(urldada)
#             #resolved2 = urlresolver.resolve(urldada)
#         except:
#             xbmc.log("ERROR RESOLVER ADDON: " + urldada)
#             resolved = False
#         return resolved

def search(texto):
    
    texto = texto.replace(" ", "+")
    item = Item
    
    req=requests.get(host)
    #import web_pdb;web_pdb.set_trace()
    if req.status_code != 200:
        return
    
    data=req.text
    ##data = httptools.downloadpage(host).data
    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')

    req=requests.get("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv)
    #import web_pdb;web_pdb.set_trace()
    if req.status_code != 200:
        return
    
    data=req.text

    #data = httptools.downloadpage("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv).data
    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:                                       #Evita un loop si error
        item.url = host_search %(texto, cse_token)
        try:
            return sub_search(item)
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        except:
            import sys
            for line in sys.exc_info():
                print("%s" % line)
    return []


def sub_search(item):
    #import web_pdb;web_pdb.set_trace()
    itemlist = []
    item_per_page=50
    while True:
        req=requests.get(item.url)
        if req.status_code != 200:
            return
    
        data=req.text
        if len(data) < 500:      #Evita un loop si error
            break

        page = int(tools.find_single_match(item.url, ".*?start=(\d+)")) + item_per_page
        item.url = tools.find_single_match(item.url, "(.*?start=)") + str(page)
        patron =  '(?s)clicktrackUrl":\s*".*?q=(.*?)".*?'
        patron += 'titleNoFormatting":\s*"([^"]+)".*?'
        patron += 'cseThumbnail.*?"src":\s*"([^"]+)"' # se usa el thumb de google
        matches = tools.find_multiple_matches(data, patron)
        for scrapedurl, scrapedtitle, scrapedthumbnail in matches:
            scrapedurl = tools.find_single_match(scrapedurl, ".*?online/")
            scrapedtitle = scrapedtitle.replace(" online", "").replace("<b>", "").replace("</b>", "")
            if "ver-" not in scrapedurl:
                continue
            year = tools.find_single_match(scrapedtitle, "\d{4}")
            title= tools.find_single_match(scrapedurl, r"Ver\s*(.*?)\s*\(\d*")
            contentTitle = scrapedtitle.replace(tools.find_single_match('\[.+', scrapedtitle),"")
            contentTitle = scrapedtitle.replace("(%s)" %year,"").replace("Ver","").strip()


            #contentTitle = (scrapedtitle + ' - ' + str(language) + ' - ' + str(year) + ' - ' + genre).replace("'","")
            infolabels,actores = tools.imdb_scraper(title,year)
            tituloespanol=infolabels.get('title')
            poster_path=infolabels.get('poster_path')

            if tituloespanol!= None:
                title=tituloespanol

            if poster_path!= None:
                thumb=poster_path


            objeto = {'accion' : 'findvideos',
                    'contentTitle' : contentTitle,
                    'year' : year,
                    'language':'language',
                    'plot' : 'plot',
                    'quality':'quality',
                    'title' : tituloespanol,           #scrapedtitle,
                    'thumbnail' :scrapedthumbnail,
                    'url' : scrapedurl,
                    'genre': 'genre',
                    'infolabels': infolabels,
                    'actores': actores}
            # itemlist.append(Item(action = "findvideos",
            #                      channel = item.channel,
            #                      contentTitle = contentTitle,
            #                      infoLabels = {"year":year},
            #                      title = scrapedtitle,
            #                      thumbnail = scrapedthumbnail,
            #                      url = scrapedurl,
            #                      ))

        itemlist.append(objeto)
    
    return itemlist

class Item:
  def __init__(self, url, age):
    self.url = url
    self.age = age

  def myfunc(self):
    print("Hello my name is " + self.url)



def get_link(urldada):
        #import web_pdb;web_pdb.set_trace()
        hmf = resolveurl.HostedMediaFile(url=urldada)
        if not hmf:
            tools.notify('Link no soportado: %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
            resolved=False
        else:
            try:
                resolved = resolveurl.resolve(urldada)
                #resolved2 = urlresolver.resolve(urldada)
            except:
                tools.notify('Pelicula borrada del servidor : %s' % tools.get_dominio(url=urldada,lang=''), duration=7500)
                xbmc.log("ERROR RESOLVER ADDON: " + urldada)
                resolved = False
        return resolved

def search2(texto):
    texto = texto.replace(" ", "+")
    item = Item

    default_headers = default_headers_sin_ua
    default_headers[
        'User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 OPR/73.0.3856.284'
    req = urllib2.Request(host, None, default_headers)
    data = urllib2.urlopen(req).read()

    # req = requests.get(host)
    # # import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return
    #
    # data = req.text
    ##data = httptools.downloadpage(host).data
    cxv = tools.find_single_match(data, 'cx" value="([^"]+)"')

    # req = requests.get("https://cse.google.es/cse.js?hpg=1&cx=%s" % cxv)
    # # import web_pdb;web_pdb.set_trace()
    # if req.status_code != 200:
    #     return
    #
    # data = req.text

    req = urllib2.Request("https://cse.google.es/cse.js?hpg=1&cx=%s" % cxv, None, default_headers)
    data = urllib2.urlopen(req).read()

    # data = httptools.downloadpage("https://cse.google.es/cse.js?hpg=1&cx=%s" %cxv).data
    cse_token = tools.find_single_match(data, 'cse_token": "([^"]+)"')
    if cse_token:  # Evita un loop si error
        item.url = host_search % (texto, cse_token)
        #try:
        resultados =sub_search2(item)
        return resultados
        # Se captura la excepción, para no interrumpir al buscador global si un canal falla
        # except:
        #     import sys
        #     for line in sys.exc_info():
        #         print("%s" % line)
    return []


def sub_search2(itembusqueda):
    # import web_pdb;web_pdb.set_trace()
    global objeto
    itemlist = []
    item_per_page = 50
    #while True:
    default_headers = default_headers_sin_ua
    default_headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 OPR/73.0.3856.284'
    req = urllib2.Request(itembusqueda.url, None, default_headers)
    # if req.status_code != 200:
    #     return

    data = urllib2.urlopen(req).read()

    if len(data) < 500:  return # Evita un loop si error
        #break
    patrongetjson=r'.*?google\.search\.S.*?\((.*?)\);'
    jsontext=tools.find_single_match(data,patrongetjson)
    #aqui tenemos los resultados

    json_data = json.loads(jsontext)
    resultCount=int(json_data['cursor'].get('resultCount'))
    paginaactual=int(json_data['cursor'].get('currentPageIndex'))
    result=json_data['results']
    #return result
    for item in result:
        plot=item['contentNoFormatting']
        title = item['title'].replace(" online", "")
        if 'Lista de Peliculas' in title:continue
        url = item['url']
        year = tools.find_single_match(title, "\d{4}")
        title=title.replace('('+year+')',"")
        if '|' in title:
            regex = r"(.*?)\|"
            title=tools.find_single_match(title,regex)
        title=title.replace('Ver ','').strip()
        title=tools.htmlclean(title)

        scrapedthumbnail=item['richSnippet']['cseThumbnail']['src']
        try:
            genre=item['breadcrumbUrl']['crumbs'][0]
        except:
            genre=''

        contentTitle = (title + ' - ' + str(year)).replace("'", "")
        infolabels, actores = tools.imdb_scraper(title, year)
        if (infolabels != None and len(infolabels)> 0):
            # respuesta["plot"] = plot
            # respuesta["id"] = id
            # respuesta["votes"] = votes
            # respuesta["title"] = title
            # respuesta["rating"] = rating
            # respuesta["aired"] = aired
            # respuesta["poster_path"] = poster_path
            # respuesta["castandrole"] = castandrole

            # actoressetcast["name"]=name
            # actoressetcast["role"]=role
            # actoressetcast["thumbnail"]=thumbnail
            # actoressetcast["order"]=order


            tituloespanol = infolabels.get('title')
            poster_path = infolabels.get('poster_path')
            contentTitle = (title + ' - ' + str(year) ).replace("'", "")

            if tituloespanol != None or tituloespanol !='':
                title = tituloespanol

            if poster_path != None or poster_path !='':
                scrapedthumbnail = poster_path

        objeto = {'accion': 'findvideos',
                      'contentTitle': contentTitle,
                      'year': year,
                      'language': 'language',
                      'plot': plot,
                      'quality': 'quality',
                      'title': title,  # scrapedtitle,
                      'thumbnail': scrapedthumbnail,
                      'url': url,
                      'genre': genre,
                      'infolabels': infolabels,
                      'actores': actores}
            # itemlist.append(Item(action = "findvideos",
            #                      channel = item.channel,
            #                      contentTitle = contentTitle,
            #                      infoLabels = {"year":year},
            #                      title = scrapedtitle,
            #                      thumbnail = scrapedthumbnail,
            #                      url = scrapedurl,
            #                      ))

        itemlist.append(objeto)

    return itemlist

def get_languages(valores):
    regex = r"\((V[A-Z].*?)\)"
    language = []
    result = ''
    languages = re.findall(regex, valores, re.DOTALL)
    if len(languages)>0:
        for lang in languages:
            langu = IDIOMAS.get(lang, lang)
            language.append(langu)
        language = sorted(language)
        result=','.join(language)
    return result


