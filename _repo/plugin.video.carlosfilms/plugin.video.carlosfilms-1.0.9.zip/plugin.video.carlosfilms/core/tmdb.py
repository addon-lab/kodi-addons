# coding=utf-8

import json
import urllib

from core.httptools import get_link


def imdb_scraper(titulo ,year=0):
    # import web_pdb;web_pdb.set_trace()
    imdbtitulo = titulo
    api_base = 'https://api.themoviedb.org/3/search/movie?'
    params_imdb ='api_key=a1ab8b8669da03637a4b98fa39c39228&query= '+ imdbtitulo.replace(' ','+') +'&language=es'
    if year > 0:
        params_imdb = 'api_key=a1ab8b8669da03637a4b98fa39c39228&query=' + imdbtitulo.replace(' ','+') + '&language=es&year=' + str(year)
    imdb = api_base + params_imdb
    plot = ''
    respuesta = {}
    datosimdb=get_link(imdb)
    imdbjson = json.loads(datosimdb)

    actoresn = {}
    if imdbjson.get('total_results') > 0:
        for item in imdbjson.get('results'):
            tituloimdb=item.get('title').upper()
            titulopasado=imdbtitulo.upper()
            tituloimdb_original=item.get('original_title').upper()

            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                plot = item.get('overview')

                # si no se obtiene plot en español, lo traemos en ingles
                if plot == '':
                    imdbingles = imdb.replace('language=es', 'language=en')
                    datosimdbingles = get_link(imdbingles)
                    imdbjsoningles = json.loads(datosimdbingles)
                    if imdbjsoningles.get('total_results') > 0:
                        for itemingles in imdbjsoningles.get('results'):
                            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                                plot = itemingles.get('overview')

                id = str(item.get('id'))
                originaltitle = item.get('original_title')
                votes = item.get('popularity')
                title = item.get('title')
                rating = item.get('vote_average')
                aired = item.get('release_date')
                poster_path = item.get('poster_path')
                if poster_path != None:
                    poster_path = 'https://image.tmdb.org/t/p/w300' + poster_path

                castandrole, actoresn = imdb_scraper_byid2(id)

                respuesta["plot"] = plot
                respuesta["id"] = id
                respuesta["votes"] = votes
                respuesta["title"] = title
                respuesta["rating"] = rating
                respuesta["aired"] = aired
                respuesta["poster_path"] = poster_path
                respuesta["castandrole"] = castandrole
    else:
        respuesta["plot"] = ''
        respuesta["id"] = ''
        respuesta["votes"] = ''
        respuesta["title"] = ''
        respuesta["rating"] = ''
        respuesta["aired"] = ''
        respuesta["poster_path"] = ''
        respuesta["castandrole"] = ''



    return respuesta, actoresn

def imdb_scraper_byid2(id):
    url='https://api.themoviedb.org/3/movie/{movie_id}/credits?api_key=a1ab8b8669da03637a4b98fa39c39228&language=es-ES'
    urlpreparada=url.replace('{movie_id}',id)
    datosimdb = get_link(urlpreparada)

    #datosimdb = requests.get(urlpreparada).text
    imdbjson = json.loads(datosimdb)
    dic=[]
    dicsetcast=[]
    actores={}
    actoressetcast={}

    #actors = [{"name": "Actor 1", "role": "role 1"}, {"name": "Actor 2", "role": "role 2"}]
    for item in imdbjson.get('cast'):
        name=item.get('name')
        role=item.get('character')
        thumbnail=item.get('profile_path')
        if thumbnail != None:
            thumbnail = 'https://image.tmdb.org/t/p/w185/' + thumbnail
        order=item.get('cast_id')

        actores = [name, role]
        dic.append(actores)
        actoressetcast={'name':name,'role': role,'thumbnail':thumbnail,'order': order}
        dicsetcast.append(actoressetcast)

    return dic,dicsetcast