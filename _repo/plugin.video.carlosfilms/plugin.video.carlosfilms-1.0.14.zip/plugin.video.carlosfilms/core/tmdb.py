# coding=utf-8

import json
import urllib

from core.httptools import get_httpdocument


def imdb_scraper(titulo ,lock,year=0):
    #import web_pdb;web_pdb.set_trace()
    imdbtitulo = titulo
    api_base = 'https://api.themoviedb.org/3/search/movie?'
    params_imdb ='api_key=a1ab8b8669da03637a4b98fa39c39228&query= '+ imdbtitulo.replace(' ','+') +'&language=es'
    if year > 0:
        params_imdb = 'api_key=a1ab8b8669da03637a4b98fa39c39228&query=' + imdbtitulo.replace(' ','+') + '&language=es&year=' + str(year)
    imdb = api_base + params_imdb
    plot = ''
    respuesta = {}
    resultfinal={}
    datosimdb=get_httpdocument(imdb)
    imdbjson = json.loads(datosimdb)

    actoresn = {}
    if imdbjson.get('total_results') > 0:
        for item in imdbjson.get('results'):
            tituloimdb=item.get('title').upper()
            titulopasado=imdbtitulo.upper()
            tituloimdb_original=item.get('original_title').upper()

            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                plot = item.get('overview')

                # si no se obtiene plot en español, lo traemos en ingles
                if plot == '':
                    imdbingles = imdb.replace('language=es', 'language=en')
                    datosimdbingles = get_httpdocument(imdbingles)
                    imdbjsoningles = json.loads(datosimdbingles)
                    if imdbjsoningles.get('total_results') > 0:
                        for itemingles in imdbjsoningles.get('results'):
                            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                                plot = itemingles.get('overview')

                id = str(item.get('id'))
                originaltitle = item.get('original_title')
                votes = item.get('popularity')
                title = item.get('title')
                rating = item.get('vote_average')
                aired = item.get('release_date')
                poster_path = item.get('poster_path')
                if poster_path != None:
                    poster_path = 'https://image.tmdb.org/t/p/w300' + poster_path

                castandrole, actoresn = imdb_scraper_byid2(id)

                respuesta["plot"] = plot
                respuesta["id"] = id
                respuesta["votes"] = votes
                respuesta["title"] = title
                respuesta["rating"] = rating
                respuesta["aired"] = aired
                respuesta["poster_path"] = poster_path
                respuesta["castandrole"] = castandrole
    else:
        respuesta["plot"] = ''
        respuesta["id"] = ''
        respuesta["votes"] = ''
        respuesta["title"] = ''
        respuesta["rating"] = ''
        respuesta["aired"] = ''
        respuesta["poster_path"] = ''
        respuesta["castandrole"] = ''

    # if lock and lock.locked():
    #     lock.release()
    resultfinal['respuesta'] = respuesta
    resultfinal['actores'] = actoresn

    return respuesta, actoresn

def imdb_scraper_byid2(id):
    url='https://api.themoviedb.org/3/movie/{movie_id}/credits?api_key=a1ab8b8669da03637a4b98fa39c39228&language=es-ES'
    urlpreparada=url.replace('{movie_id}',id)
    datosimdb = get_httpdocument(urlpreparada)

    #datosimdb = requests.get(urlpreparada).text
    imdbjson = json.loads(datosimdb)
    dic=[]
    dicsetcast=[]
    actores={}
    actoressetcast={}

    #actors = [{"name": "Actor 1", "role": "role 1"}, {"name": "Actor 2", "role": "role 2"}]
    for item in imdbjson.get('cast'):
        name=item.get('name')
        role=item.get('character')
        thumbnail=item.get('profile_path')
        if thumbnail != None:
            thumbnail = 'https://image.tmdb.org/t/p/w185/' + thumbnail
        order=item.get('cast_id')

        actores = [name, role]
        dic.append(actores)
        actoressetcast={'name':name,'role': role,'thumbnail':thumbnail,'order': order}
        dicsetcast.append(actoressetcast)

    return dic,dicsetcast


def get_tmdb(item_list):
    """
    De manera concurrente, obtiene los datos de los items incluidos en la lista item_list.

    La API tiene un limite de 40 peticiones por IP cada 10'' y por eso la lista no deberia tener mas de 30 items
    para asegurar un buen funcionamiento de esta funcion.

    @param item_list: listado de objetos Item que representan peliculas, series o capitulos. El atributo
        infoLabels de cada objeto Item sera modificado incluyendo los datos extras localizados.
    @type item_list: list
    """
    import threading

    threads_num = 10
    semaforo = threading.Semaphore(threads_num)
    lock = threading.Lock()
    r_list = list()
    i = 0
    l_hilo = list()

    def sub_thread(_item, _i):
        semaforo.acquire()
        ret = imdb_scraper_itemlist(_item, lock)
        # logger.debug(str(ret) + "item: " + _item.tostring())
        semaforo.release()
        r_list.append((_i, _item, ret))

    for item in item_list:
        t = threading.Thread(target=sub_thread, args=(item, i))
        t.start()
        i += 1
        l_hilo.append(t)

    # esperar q todos los hilos terminen
    for x in l_hilo:
        x.join()

    # Ordenar lista de resultados por orden de llamada para mantener el mismo orden q item_list
    r_list.sort(key=lambda i: i[0])

    # Reconstruir y devolver la lista solo con los resultados de las llamadas individuales
    return [ii[2] for ii in r_list]

def imdb_scraper_itemlist(itemlist,lock):
    #import web_pdb;web_pdb.set_trace()

    imdbtitulo = itemlist['title']
    year = itemlist['year']
    api_base = 'https://api.themoviedb.org/3/search/movie?'
    params_imdb ='api_key=a1ab8b8669da03637a4b98fa39c39228&query= '+ imdbtitulo.replace(' ','+') +'&language=es'
    if year > 0:
        params_imdb = 'api_key=a1ab8b8669da03637a4b98fa39c39228&query=' + imdbtitulo.replace(' ','+') + '&language=es&year=' + str(year)
    imdb = api_base + params_imdb
    plot = ''
    respuesta = {}
    resultfinal = {}
    datosimdb = get_httpdocument(imdb)
    imdbjson = json.loads(datosimdb)
    encontrado=False

    actoresn = {}
    if imdbjson.get('total_results') > 0:
        for item in imdbjson.get('results'):
            tituloimdb=item.get('title').upper()
            titulopasado=imdbtitulo.upper()
            tituloimdb_original=item.get('original_title').upper()

            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                encontrado=True
                plot = item.get('overview')

                # si no se obtiene plot en español, lo traemos en ingles
                if plot == '':
                    imdbingles = imdb.replace('language=es', 'language=en')
                    datosimdbingles = get_httpdocument(imdbingles)
                    imdbjsoningles = json.loads(datosimdbingles)
                    if imdbjsoningles.get('total_results') > 0:
                        for itemingles in imdbjsoningles.get('results'):
                            if titulopasado == tituloimdb_original or titulopasado == tituloimdb:
                                plot = itemingles.get('overview')

                id = str(item.get('id'))
                originaltitle = item.get('original_title')
                votes = item.get('popularity')
                title = item.get('title')
                rating = item.get('vote_average')
                aired = item.get('release_date')
                poster_path = item.get('poster_path')
                if poster_path != None:
                    poster_path = 'https://image.tmdb.org/t/p/w300' + poster_path

                castandrole, actoresn = imdb_scraper_byid2(id)

                respuesta["plot"] = plot
                respuesta["id"] = id
                respuesta["votes"] = votes
                respuesta["title"] = title
                respuesta["rating"] = rating
                respuesta["aired"] = aired
                respuesta["poster_path"] = poster_path
                respuesta["castandrole"] = castandrole
        
        if encontrado == False:
            item = imdbjson.get('results')[0]
            plot = item.get('overview')
            id = str(item.get('id'))
            originaltitle = item.get('original_title')
            votes = item.get('popularity')
            title = item.get('title')
            rating = item.get('vote_average')
            aired = item.get('release_date')
            poster_path = item.get('poster_path')
            if poster_path != None:
                poster_path = 'https://image.tmdb.org/t/p/w300' + poster_path

            castandrole, actoresn = imdb_scraper_byid2(id)

            respuesta["plot"] = plot
            respuesta["id"] = id
            respuesta["votes"] = votes
            respuesta["title"] = title
            respuesta["rating"] = rating
            respuesta["aired"] = aired
            respuesta["poster_path"] = poster_path
            respuesta["castandrole"] = castandrole


    else:
        respuesta["plot"] = ''
        respuesta["id"] = ''
        respuesta["votes"] = ''
        respuesta["title"] = ''
        respuesta["rating"] = ''
        respuesta["aired"] = ''
        respuesta["poster_path"] = ''
        respuesta["castandrole"] = ''

    # if lock and lock.locked():
    #     lock.release()
    #import web_pdb;web_pdb.set_trace()
    resultfinal['itemlist'] = itemlist
    resultfinal['infolabels'] = respuesta
    resultfinal['actores'] = actoresn
    if lock and lock.locked():
                lock.release()

    return resultfinal
