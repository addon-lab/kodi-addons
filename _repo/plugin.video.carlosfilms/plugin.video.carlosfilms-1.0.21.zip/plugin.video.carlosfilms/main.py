#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import re
import xbmcplugin
import urlparse
#import json
#import requests
#from bs4 import BeautifulSoup
#import jsbeautifier
import base64
import xbmcgui
import time


#from urlparse import urlparse



from core.gnula import get_datospartida,get_peliculas,get_link ,findvideos,get_generos,list_peliculas_generos,search_alfa,get_peliculasAleatorio
from core import logger
from core import tools

args = urlparse.parse_qs(sys.argv[2][1:])
action = args.get('action', None)
host = "https://www.gnula.nu/"

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
final_titulo = ''
final_imagen = ''





if action is None:
   

    #borrar cache si esta configurado a true en setting
    borrarcache = tools.getcachesetting()
    if borrarcache:
        tools.remove_dir(tools.getAddonUserDataFolder())

    

    listapartida=get_datospartida()

    for elemento in listapartida:

        url = tools.build_url({'action': elemento.get('accion'), 'url_':elemento.get('urlvalue'),'imagen':elemento.get('imagen'),'nombre':elemento.get('nombre'),'posicion':0})
        tools.addItemMenu(label = elemento.get('nombre'),thumbnail= elemento.get('imagen'), url= url,IsPlayable = 'false', isFolder= True )

    #xbmcplugin.addSortMethod(handle=addon_handle , sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.endOfDirectory(addon_handle) 

else:

    # if action[0] == 'Inicio':
    #     #import web_pdb;web_pdb.set_trace()
    #     listapartida=get_datospartida()

    #     for elemento in listapartida:
    #         url = tools.build_url({'action': elemento.get('accion'), 'url_':elemento.get('url'),'imagen':elemento.get('imagen'),'nombre':elemento.get('nombre'),'posicion':0})
    #         tools.addItemMenu(label = elemento.get('nombre'),thumbnail= elemento.get('imagen'), url= url,IsPlayable = 'false', isFolder= True )

    #     xbmcplugin.endOfDirectory(addon_handle) 

   
    if action[0] == 'peliculas':
        #import web_pdb;web_pdb.set_trace()
        imagenestrenos = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/estrenos.png").decode('utf-8')
    
        url_ = args.get('url_',None)[0]
        image_=args.get('imagen',None)[0]
        nombreCanal_ = args.get('nombre', None)[0]
        posicion=args.get('posicion', 0)[0]
        urlclave = url_
        resultado=get_peliculas(url_,posicion)

        #import web_pdb;web_pdb.set_trace()

        # itemlist.append(dic{'action' = 'findvideos',
        #                      'channel' = item.channel,
        #                      'contentTitle' = scrapedtitle,
        #                      'infoLabels' = {"year":year},
        #                      'language'=language,
        #                      'plot' = plot,
        #                      'quality'=quality,
        #                      'title' = title,
        #                      'thumbnail' = scrapedthumbnail,
        #                      'url' = scrapedurl
        #					   'genre' = genre
        #                      })
        for elemento in resultado:
            siguiente=elemento.get('contentTitle')
            textoColoreado=tools.giveColor(siguiente,'orange',True)
            
            if siguiente=='Siguiente >>':
                url = tools.build_url({'action': elemento.get('accion'), 'url_':url_,'imagen':elemento.get('scrapedthumbnail'),'nombre':elemento.get('title'),'posicion':elemento.get('posicion') })
                tools.addItemMenu(label = textoColoreado,thumbnail= elemento.get('thumbnail'), url= url,IsPlayable = 'false', isFolder= True)
            else:
                try:
                    infolabels=elemento.get('infolabels')
                #    infolabels = {'title':'Avatar','year':2009,'code':'tt0499549','originaltitle':'Avatar','plot':'A paraplegic marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home.'}
                except:
                    logger.debug(elemento.get('year'))

                try:
                    actores=elemento.get('actores')
                except:
                    logger.debug(elemento.get('year'))
            	
            	action=elemento.get('accion') # findvideos y otros
                contentTitle=elemento.get('contentTitle')
                contentTitleColor=tools.giveColor(contentTitle,'orange',False)
            	
                #import web_pdb;web_pdb.set_trace()
                url = tools.build_url({'action': action, 'url_':elemento.get('url'),'imagen':elemento.get('scrapedthumbnail'),'nombre':elemento.get('contentTitle')})
                tools.addItemMenu(label = contentTitle,thumbnail= elemento.get('thumbnail'), url= url,IsPlayable = 'true', isFolder= False, infolabel= infolabels, actores=actores)
                #logger.debug(action)




        # urlresult=decrypted.decode('latin-1')+'|Referer=https://embed.latino-web-tv.com/tnt'
        # tools.addItemMenu(label=nombreCanal_, thumbnail=image_, url=urlresult, IsPlayable='false', isFolder=True)
        
        # #jugar dando valores para vr como los presenta en kodi
        # #context=xbmcplugin.setContent(addon_handle, 'videos')
        # #tools.setView(context,'IconWall')
        #xbmcplugin.addSortMethod(handle=addon_handle , sortMethod=xbmcplugin.SORT_METHOD_LABEL )

        # ir a pagina principal
        # url = tools.build_url({'action': 'Inicio', 'url_':'','imagen':imagenestrenos,'nombre':'Inicio','posicion':0 })
        # tools.addItemMenu(label = '<< Inicio',thumbnail= imagenestrenos, url= url,IsPlayable = 'false', isFolder= True)

        xbmcplugin.endOfDirectory(addon_handle)

    if action[0] == 'peliculasAleatorias':
            #import web_pdb;web_pdb.set_trace()
            imagenestrenos = xbmc.translatePath("special://home/addons/plugin.video.carlosfilms/resources/media/estrenos.png").decode('utf-8')
        
            url_ = args.get('url_',None)[0]
            image_=args.get('imagen',None)[0]
            nombreCanal_ = args.get('nombre', None)[0]
            urlclave = url_
            resultado=get_peliculasAleatorio(url_)

            for elemento in resultado:
                siguiente=elemento.get('contentTitle')
                textoColoreado=tools.giveColor(siguiente,'orange',True)
                
                
                try:
                    infolabels=elemento.get('infolabels')
                #    infolabels = {'title':'Avatar','year':2009,'code':'tt0499549','originaltitle':'Avatar','plot':'A paraplegic marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home.'}
                except:
                    logger.debug(elemento.get('year'))

                try:
                    actores=elemento.get('actores')
                except:
                    logger.debug(elemento.get('year'))
                
                action=elemento.get('accion') # findvideos y otros
                contentTitle=elemento.get('contentTitle')
                contentTitleColor=tools.giveColor(contentTitle,'orange',False)
                
                #import web_pdb;web_pdb.set_trace()
                url = tools.build_url({'action': action, 'url_':elemento.get('url'),'imagen':elemento.get('scrapedthumbnail'),'nombre':elemento.get('contentTitle')})
                tools.addItemMenu(label = contentTitle,thumbnail= elemento.get('thumbnail'), url= url,IsPlayable = 'true', isFolder= False, infolabel= infolabels, actores=actores)


            xbmcplugin.endOfDirectory(addon_handle)


    if action[0] == 'generos':
        #import web_pdb; web_pdb.set_trace()
        url = args.get('url_',None)[0]

        matches = get_generos(url)

        # {'accion': 'peliculas_generos',
        #           'title': titulo,
        #           'url': url
        #           }

        for item in matches:

            title=item.get('title')
            url = item.get('url')
            accion=item.get('accion')
            try:
                plot = item.get('plot')
            except:
                plot=''

            try:
               infolabel={
                'title': title,
                'plot':plot
                }
            except:
                logger.debug(elemento.get('title'))

            #import web_pdb; web_pdb.set_trace()

            url = tools.build_url({'action': accion, 'url_':item.get('url'),'imagen':'','nombre':item.get('title')})
            tools.addItemMenu(label = title,thumbnail= 'thumbnail', url= url, IsPlayable = 'false', isFolder= True, infolabel= infolabel)

        xbmcplugin.endOfDirectory(addon_handle)


    if action[0] == 'peliculas_generos':
        #import web_pdb; web_pdb.set_trace()
        url = args.get('url_',None)[0]
        try:
            posicion=args.get('posicion', 0)[0]
        except:
            posicion=0
        

        matches = list_peliculas_generos(url,posicion)

        # objeto = {'accion': 'findvideos',
        #               'contentTitle': contentTitle,
        #               'year': year,
        #               'languages': languages,
        #               'plot': plot,
        #               'quality': calidad,
        #               'title': title,
        #               'thumbnail': image,
        #               'url': url,
        #               'genre': 'generos',
        #               'infolabels': infolabels,
        #               'actores': actores}
     

        if matches == None:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('No Localizada Pelicula', ['mal', 'matches none'])
        else:
            for item in matches:
                
                if item.get('title') == 'Siguiente >>':
                    siguienteColoreado=tools.giveColor(item.get('title'),'red',True)
                    urlsiguiente = tools.build_url({'action': item.get('accion'), 'url_':item.get('url'),'imagen':item.get('thumbnail'),'nombre':item.get('title'),'posicion':item.get('posicion') })
                    tools.addItemMenu(label = siguienteColoreado,thumbnail= item.get('thumbnail'), url= urlsiguiente, IsPlayable = 'false', isFolder= True)
                else:

                    titulo=item.get('title')
                    url_ = item.get('url')
                    accion= item.get('accion')
                    imagen= item.get('thumbnail')
                    contentTitle = item.get('contentTitle')
                    
                    try:
                        year= item.get('year')
                    except:
                        year=0
                    
                    try:
                        infolabels=item.get('infolabels')
                    except:
                        infolabels={}
                    try:
                        actores=item.get('actores')
                    except:
                        actores={}

                    url = tools.build_url({'action': accion, 'url_':url_,'imagen': imagen,'nombre':titulo})
                    tools.addItemMenu(label = contentTitle,thumbnail= imagen, url= url, IsPlayable = 'true', isFolder= False, infolabel= infolabels,actores=actores)

            xbmcplugin.endOfDirectory(addon_handle)
    
    if action[0] == 'searcher':
        
        textobusqueda=''
        keyboard = xbmc.Keyboard('', 'Buscador de peliculas CarlosFilms')
        keyboard.doModal()
        if keyboard.isConfirmed():
            textobusqueda= keyboard.getText()
            resultado=search_alfa(textobusqueda)
            
        else:
            textobusqueda= keyboard.getText()
            resultado = None
            


        #resultado=search(textobusqueda)
        #import web_pdb; web_pdb.set_trace()
        #textobusqueda=textobusqueda.replace(' ','+')
        

        if resultado is not None:
            #import web_pdb; web_pdb.set_trace()
            for elemento in resultado:
                siguiente=elemento.get('contentTitle')
                textoColoreado=tools.giveColor(siguiente,'red',True)
                
                if siguiente=='Siguiente >>':
                    url = tools.build_url({'action': elemento.get('accion'), 'url_':url_,'imagen':elemento.get('scrapedthumbnail'),'nombre':elemento.get('title'),'posicion':elemento.get('posicion') })
                    tools.addItemMenu(label = textoColoreado,thumbnail= elemento.get('thumbnail'), url= url,IsPlayable = 'false', isFolder= True)
                else:
                    try:
                        infolabels=elemento.get('infolabels')
                    #    infolabels = {'title':'Avatar','year':2009,'code':'tt0499549','originaltitle':'Avatar','plot':'A paraplegic marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home.'}
                    except:
                        logger.debug(elemento.get('year'))

                    try:
                        actores=elemento.get('actores')
                    except:
                        logger.debug(elemento.get('year'))

                    # objeto = {'accion' : 'findvideos',
                    # 'contentTitle' : contentTitle,
                    # 'year' : year,
                    # 'language':'language',
                    # 'plot' : 'plot',
                    # 'quality':'quality',
                    # 'title' : scrapedtitle,           #scrapedtitle,
                    # 'thumbnail' :scrapedthumbnail,
                    # 'url' : scrapedurl,
                    # 'genre': 'genre'
                    # }
                    
                    action=elemento.get('accion') # findvideos y otros
                    action='findvideos'
                    contentTitle=elemento.get('contentTitle')
                    contentTitleColor=tools.giveColor(contentTitle,'orange',False)
                    surl=elemento.get('url')
                    
                    
                    url = tools.build_url({'action': action, 'url_':surl,'imagen':elemento.get('scrapedthumbnail'),'nombre':elemento.get('contentTitle')})
                    tools.addItemMenu(label = contentTitle,thumbnail= elemento.get('thumbnail'), url= url, IsPlayable = 'true', isFolder= False, infolabel= infolabels, actores=actores)
                    #logger.debug(action)

                    # #import web_pdb;web_pdb.set_trace()
                    # url = tools.build_url({'action': action, 'url_':elemento.get('url'),'imagen':elemento.get('scrapedthumbnail'),'nombre':elemento.get('contentTitle')})
                    # tools.addItemMenu(label = contentTitle,thumbnail= elemento.get('thumbnail'), url= url,IsPlayable = 'true', isFolder= False, infolabel= infolabels, actores=actores)
      
            xbmcplugin.endOfDirectory(addon_handle)

    if action[0] == 'findvideos':

        #import web_pdb; web_pdb.set_trace()


        url_ = args.get('url_',None)[0]
        titulo=args.get('nombre',None)[0]
        imagen=args.get('imagen',None)[0]
        listaurlresolver=[]
        lista=[]
        
        matches=findvideos(url_)
        #import web_pdb; web_pdb.set_trace()
        if matches != None:
            matches=sorted(matches, key=lambda it: it.get('lang'))

            for elemento in matches:
                url=elemento.get('url').encode('utf-8')
                lang=elemento.get('lang')
                if tools.isDisableServidor(url):continue
                dominio=tools.get_dominio(url=url,lang=lang)
                lista.append(tools.giveColor(dominio,'white'))


            
            cierra = 1
            #import web_pdb; web_pdb.set_trace()
            while cierra > 0:

                dialog = xbmcgui.Dialog()
                ret = dialog.select('Elegir un Servidor', lista)
                
                if ret >= 0:
                    elegido=matches[ret].get('url').encode('utf-8')
                    #lista[ret]=tools.giveColor(elegido,'red',False)
                    #elegido=tools.giveColor(matches[ret].get('url').encode('utf-8'),'red',False)
                    url=get_link(elegido)
                    if url != False:
                        tools.play_video(url=url,handle=addon_handle)
                        #cierra = -1
                        #xbmcplugin.endOfDirectory(addon_handle,succeeded=False)
                        break
                    else:
                        lista=tools.giveColorItemSelecionadoLista(lista, ret ,'0xFFFF3300')
                    #     #return
                    #     xbmcplugin.endOfDirectory(addon_handle,succeeded=False)
                else:
                    # dialog = xbmcgui.Dialog()
                    # dialog.ok('Informacion', 'Seleccion abortada')
                    #return
                    cierra= -1
                    xbmcplugin.endOfDirectory(addon_handle,succeeded=False)
                    break
            
        else:
            #return
            xbmcplugin.endOfDirectory(addon_handle) #,succeeded=False)




    





